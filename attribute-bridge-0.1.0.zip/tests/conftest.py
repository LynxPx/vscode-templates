"""Shared fixtures for the AttributeBridge test suite."""

from __future__ import annotations

from unittest.mock import MagicMock, create_autospec

import pytest

from app.clients.datahub_client import DataHubClient
from app.clients.k8s_client import K8sClient
from app.clients.keycloak_client import KeycloakClient
from app.config import Settings
from app.models.domain import GroupOwnershipState
from app.services.configmap_sync import ConfigMapSyncService
from app.services.group_mapper import DirectGroupNameMapper, GroupNameMapper
from app.services.keycloak_sync import KeycloakSyncService
from app.services.opa_policy_builder import OpaPolicyBuilder
from app.services.ownership_resolver import OwnershipResolver
from app.services.reconciler import Reconciler

# ------------------------------------------------------------------
# Sample data
# ------------------------------------------------------------------

DATASET_A = "urn:li:dataset:(urn:li:dataPlatform:trino,sales.orders,PROD)"
DATASET_B = "urn:li:dataset:(urn:li:dataPlatform:trino,sales.customers,PROD)"
DATASET_C = "urn:li:dataset:(urn:li:dataPlatform:trino,marketing.campaigns,PROD)"
DP_1 = "urn:li:dataProduct:sales-data"
DP_2 = "urn:li:dataProduct:marketing-data"
GROUP_ANALYTICS = "analytics"
GROUP_MARKETING = "marketing"
GROUP_URN_ANALYTICS = "urn:li:corpGroup:analytics"
GROUP_URN_MARKETING = "urn:li:corpGroup:marketing"


# ------------------------------------------------------------------
# Settings
# ------------------------------------------------------------------


@pytest.fixture()
def settings() -> Settings:
    """Return a Settings instance suitable for testing (no external deps)."""
    return Settings(
        datahub_url="http://localhost:8080",
        datahub_token="test-token",
        keycloak_url="http://localhost:8180",
        keycloak_realm="test",
        keycloak_client_id="test-client",
        keycloak_client_secret="test-secret",
        k8s_in_cluster=False,
        k8s_namespace="test-ns",
        k8s_configmap_name="test-cm",
        k8s_configmap_key="policy.json",
        dry_run=False,
        log_level="DEBUG",
    )


# ------------------------------------------------------------------
# Mock clients
# ------------------------------------------------------------------


@pytest.fixture()
def mock_datahub_client() -> MagicMock:
    """Return a mock DataHubClient with autospecced methods."""
    return create_autospec(DataHubClient, instance=True)


@pytest.fixture()
def mock_keycloak_client() -> MagicMock:
    """Return a mock KeycloakClient with autospecced methods."""
    return create_autospec(KeycloakClient, instance=True)


@pytest.fixture()
def mock_k8s_client() -> MagicMock:
    """Return a mock K8sClient with autospecced methods."""
    return create_autospec(K8sClient, instance=True)


# ------------------------------------------------------------------
# Service instances backed by mocks
# ------------------------------------------------------------------


@pytest.fixture()
def group_mapper() -> GroupNameMapper:
    """Return a direct (identity) group name mapper."""
    return DirectGroupNameMapper()


@pytest.fixture()
def ownership_resolver(mock_datahub_client: MagicMock) -> OwnershipResolver:
    """Return an OwnershipResolver backed by a mocked DataHub client."""
    return OwnershipResolver(mock_datahub_client)


@pytest.fixture()
def policy_builder() -> OpaPolicyBuilder:
    """Return a real OpaPolicyBuilder."""
    return OpaPolicyBuilder()


@pytest.fixture()
def keycloak_sync(
    mock_keycloak_client: MagicMock,
    group_mapper: GroupNameMapper,
) -> KeycloakSyncService:
    """Return a KeycloakSyncService backed by a mocked client."""
    return KeycloakSyncService(mock_keycloak_client, group_mapper)


@pytest.fixture()
def configmap_sync(
    mock_k8s_client: MagicMock,
    policy_builder: OpaPolicyBuilder,
) -> ConfigMapSyncService:
    """Return a ConfigMapSyncService backed by a mocked K8s client."""
    return ConfigMapSyncService(mock_k8s_client, policy_builder)


@pytest.fixture()
def reconciler(
    ownership_resolver: OwnershipResolver,
    keycloak_sync: KeycloakSyncService,
    configmap_sync: ConfigMapSyncService,
    policy_builder: OpaPolicyBuilder,
    group_mapper: GroupNameMapper,
    settings: Settings,
) -> Reconciler:
    """Return a Reconciler with all dependencies mocked."""
    return Reconciler(
        ownership_resolver=ownership_resolver,
        keycloak_sync=keycloak_sync,
        configmap_sync=configmap_sync,
        policy_builder=policy_builder,
        group_mapper=group_mapper,
        settings=settings,
    )


# ------------------------------------------------------------------
# Convenience helpers
# ------------------------------------------------------------------


def make_group_state(
    group_name: str,
    dp_urns: list[str] | None = None,
    dataset_urns: list[str] | None = None,
) -> GroupOwnershipState:
    """Build a GroupOwnershipState with sensible defaults.

    Args:
        group_name: Group name.
        dp_urns: Data product URNs.
        dataset_urns: Dataset URNs.

    Returns:
        A GroupOwnershipState instance.
    """
    return GroupOwnershipState(
        group_name=group_name,
        data_product_urns=sorted(dp_urns or []),
        dataset_urns=sorted(dataset_urns or []),
    )
