"""Tests for GET /ready with optional strict readiness (Kubernetes)."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient

from app.dependencies import get_settings


@pytest.fixture()
def patched_app(monkeypatch: pytest.MonkeyPatch):
    """App with stubbed probes and reconciler so lifespan runs without external systems."""
    monkeypatch.setenv("DATAHUB_EVENT_SOURCE", "polling")
    monkeypatch.delenv("READINESS_STRICT", raising=False)
    get_settings.cache_clear()

    async def good_probes():
        from app.services.startup_dependency_checks import DependencyProbeResult

        return [
            DependencyProbeResult("DataHub", True, "ok"),
            DependencyProbeResult("Keycloak", True, "ok"),
            DependencyProbeResult("Kubernetes", True, "ok"),
        ]

    monkeypatch.setattr("app.main.run_dependency_probes_at_startup", good_probes)

    mock_r = MagicMock()
    mock_r.reconcile = AsyncMock(return_value=[])
    mock_r.handle_ownership_change = AsyncMock(return_value=[])
    monkeypatch.setattr("app.main.get_reconciler", lambda: mock_r)

    from app.main import app

    yield app
    get_settings.cache_clear()


def test_ready_ok_when_not_strict(patched_app) -> None:
    with TestClient(patched_app) as client:
        r = client.get("/ready")
    assert r.status_code == 200
    assert r.json() == {"status": "ready"}


def test_ready_503_strict_on_dependency_failure(
    patched_app, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("READINESS_STRICT", "true")
    get_settings.cache_clear()

    async def bad_probes():
        from app.services.startup_dependency_checks import DependencyProbeResult

        return [
            DependencyProbeResult("DataHub", False, "boom"),
            DependencyProbeResult("Keycloak", True, "ok"),
            DependencyProbeResult("Kubernetes", True, "ok"),
        ]

    monkeypatch.setattr("app.main.run_dependency_probes_at_startup", bad_probes)

    with TestClient(patched_app) as client:
        r = client.get("/ready")
    assert r.status_code == 503
    assert r.json() == {"status": "not_ready"}
    get_settings.cache_clear()


def test_ready_ok_strict_when_dependencies_ok(
    patched_app, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("READINESS_STRICT", "true")
    get_settings.cache_clear()

    with TestClient(patched_app) as client:
        r = client.get("/ready")
    assert r.status_code == 200
    get_settings.cache_clear()
