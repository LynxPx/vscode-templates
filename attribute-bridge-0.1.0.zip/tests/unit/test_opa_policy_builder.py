"""Unit tests for the OpaPolicyBuilder."""

from __future__ import annotations

import json

from app.services.opa_policy_builder import OpaPolicyBuilder
from tests.conftest import (
    DATASET_A,
    DATASET_B,
    DATASET_C,
    GROUP_ANALYTICS,
    GROUP_MARKETING,
    make_group_state,
)


class TestBuildPolicy:
    """Tests for OpaPolicyBuilder.build_policy."""

    def test_single_group(self, policy_builder: OpaPolicyBuilder) -> None:
        """A single group produces a valid single-entry policy."""
        states = [make_group_state(GROUP_ANALYTICS, dataset_urns=[DATASET_A, DATASET_B])]

        result = policy_builder.build_policy(states)
        data = json.loads(result)

        assert GROUP_ANALYTICS in data["groups"]
        assert data["groups"][GROUP_ANALYTICS]["allowed_access"] == sorted([DATASET_A, DATASET_B])

    def test_multiple_groups_sorted_by_name(self, policy_builder: OpaPolicyBuilder) -> None:
        """Groups appear in alphabetical order in the output."""
        states = [
            make_group_state(GROUP_MARKETING, dataset_urns=[DATASET_C]),
            make_group_state(GROUP_ANALYTICS, dataset_urns=[DATASET_A]),
        ]

        result = policy_builder.build_policy(states)
        data = json.loads(result)

        group_names = list(data["groups"].keys())
        assert group_names == sorted(group_names)

    def test_empty_states_produces_empty_groups(self, policy_builder: OpaPolicyBuilder) -> None:
        """No groups means an empty 'groups' dict."""
        result = policy_builder.build_policy([])
        data = json.loads(result)

        assert data == {"groups": {}}

    def test_deterministic_output(self, policy_builder: OpaPolicyBuilder) -> None:
        """Calling build_policy twice with the same input produces identical JSON."""
        states = [
            make_group_state(GROUP_ANALYTICS, dataset_urns=[DATASET_B, DATASET_A]),
            make_group_state(GROUP_MARKETING, dataset_urns=[DATASET_C]),
        ]

        result_1 = policy_builder.build_policy(states)
        result_2 = policy_builder.build_policy(states)

        assert result_1 == result_2

    def test_group_with_no_datasets(self, policy_builder: OpaPolicyBuilder) -> None:
        """A group that lost all DPs still appears with an empty access list."""
        states = [make_group_state(GROUP_ANALYTICS, dataset_urns=[])]

        result = policy_builder.build_policy(states)
        data = json.loads(result)

        assert data["groups"][GROUP_ANALYTICS]["allowed_access"] == []


class TestValidatePolicy:
    """Tests for OpaPolicyBuilder.validate_policy."""

    def test_valid_policy(self, policy_builder: OpaPolicyBuilder) -> None:
        """A well-formed policy passes validation."""
        policy = json.dumps(
            {
                "groups": {
                    "analytics": {"allowed_access": ["urn:a", "urn:b"]},
                }
            }
        )
        assert policy_builder.validate_policy(policy) is True

    def test_empty_groups_is_valid(self, policy_builder: OpaPolicyBuilder) -> None:
        """An empty groups dict is valid."""
        assert policy_builder.validate_policy('{"groups": {}}') is True

    def test_invalid_json(self, policy_builder: OpaPolicyBuilder) -> None:
        """Malformed JSON fails validation."""
        assert policy_builder.validate_policy("not json") is False

    def test_missing_groups_key(self, policy_builder: OpaPolicyBuilder) -> None:
        """A JSON object without a 'groups' key fails."""
        assert policy_builder.validate_policy('{"other": {}}') is False

    def test_missing_allowed_access(self, policy_builder: OpaPolicyBuilder) -> None:
        """A group without 'allowed_access' fails."""
        policy = json.dumps({"groups": {"analytics": {"other": []}}})
        assert policy_builder.validate_policy(policy) is False

    def test_allowed_access_not_list(self, policy_builder: OpaPolicyBuilder) -> None:
        """'allowed_access' must be a list."""
        policy = json.dumps({"groups": {"analytics": {"allowed_access": "not-a-list"}}})
        assert policy_builder.validate_policy(policy) is False

    def test_non_string_urn_in_list(self, policy_builder: OpaPolicyBuilder) -> None:
        """URN values must be strings."""
        policy = json.dumps({"groups": {"analytics": {"allowed_access": [123]}}})
        assert policy_builder.validate_policy(policy) is False
