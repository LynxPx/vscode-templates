"""Unit tests for the ConfigMapSyncService."""

from __future__ import annotations

import json
from unittest.mock import MagicMock

import pytest

from app.services.configmap_sync import ConfigMapSyncService
from app.services.opa_policy_builder import OpaPolicyBuilder

VALID_POLICY = json.dumps({"groups": {"g1": {"allowed_access": ["urn:a"]}}}) + "\n"
VALID_POLICY_2 = json.dumps({"groups": {"g1": {"allowed_access": ["urn:b"]}}}) + "\n"


class TestSyncPolicy:
    """Tests for ConfigMapSyncService.sync_policy."""

    def test_writes_valid_policy(
        self,
        mock_k8s_client: MagicMock,
        configmap_sync: ConfigMapSyncService,
    ) -> None:
        """A valid policy is written to the ConfigMap."""
        mock_k8s_client.read_policy_key.return_value = None

        configmap_sync.sync_policy(VALID_POLICY)

        mock_k8s_client.write_policy_data.assert_called_once_with(VALID_POLICY)

    def test_rejects_invalid_policy(
        self,
        mock_k8s_client: MagicMock,
        configmap_sync: ConfigMapSyncService,
    ) -> None:
        """An invalid policy raises ValueError and does NOT write."""
        with pytest.raises(ValueError, match="validation"):
            configmap_sync.sync_policy("not valid json")

        mock_k8s_client.write_policy_data.assert_not_called()

    def test_skips_write_when_unchanged(
        self,
        mock_k8s_client: MagicMock,
        configmap_sync: ConfigMapSyncService,
    ) -> None:
        """No write occurs if the ConfigMap already has identical content."""
        mock_k8s_client.read_policy_key.return_value = VALID_POLICY

        configmap_sync.sync_policy(VALID_POLICY)

        mock_k8s_client.write_policy_data.assert_not_called()

    def test_writes_when_content_differs(
        self,
        mock_k8s_client: MagicMock,
        configmap_sync: ConfigMapSyncService,
    ) -> None:
        """When existing content differs, the new policy is written."""
        mock_k8s_client.read_policy_key.return_value = VALID_POLICY

        configmap_sync.sync_policy(VALID_POLICY_2)

        mock_k8s_client.write_policy_data.assert_called_once_with(VALID_POLICY_2)

    def test_tracks_last_good_policy(
        self,
        mock_k8s_client: MagicMock,
        configmap_sync: ConfigMapSyncService,
    ) -> None:
        """After a successful write the policy is stored as last-known-good."""
        mock_k8s_client.read_policy_key.return_value = None

        configmap_sync.sync_policy(VALID_POLICY)

        assert configmap_sync.last_good_policy == VALID_POLICY

    def test_last_good_preserved_on_validation_failure(
        self,
        mock_k8s_client: MagicMock,
        configmap_sync: ConfigMapSyncService,
    ) -> None:
        """A failed validation does not overwrite the last-known-good policy."""
        mock_k8s_client.read_policy_key.return_value = None
        configmap_sync.sync_policy(VALID_POLICY)

        with pytest.raises(ValueError):
            configmap_sync.sync_policy("bad json")

        assert configmap_sync.last_good_policy == VALID_POLICY


class TestConfigMapSyncWithRealBuilder:
    """Test that the builder + sync integration produces correct results."""

    def test_round_trip(self, mock_k8s_client: MagicMock) -> None:
        """Policy built by OpaPolicyBuilder passes ConfigMapSync validation."""
        from tests.conftest import DATASET_A, DATASET_B, make_group_state

        builder = OpaPolicyBuilder()
        sync = ConfigMapSyncService(mock_k8s_client, builder)
        mock_k8s_client.read_policy_key.return_value = None

        states = [make_group_state("team-a", dataset_urns=[DATASET_A, DATASET_B])]
        policy_json = builder.build_policy(states)
        sync.sync_policy(policy_json)

        mock_k8s_client.write_policy_data.assert_called_once_with(policy_json)
