"""Tests for embedded DataHub Actions pipeline config (optional dependency)."""

from __future__ import annotations

import pytest

pytest.importorskip("datahub_actions")

from app.config import Settings
from app.services.datahub_actions_pipeline import build_pipeline_config_dict


def test_build_pipeline_config_dict_shape() -> None:
    """Built dict matches :class:`PipelineConfig` top-level keys."""
    settings = Settings(
        datahub_url="http://gms:8080",
        datahub_token="tok",
        datahub_kafka_bootstrap_servers="kafka:9092",
        datahub_kafka_topic="MetadataChangeLog_Versioned_v1",
        datahub_kafka_consumer_group="attribute-bridge-test",
        datahub_schema_registry_url="http://gms:8080/schema-registry/api/",
    )
    cfg = build_pipeline_config_dict(settings)

    assert cfg["name"] == "attribute-bridge-test"
    assert cfg["enabled"] is True
    assert cfg["source"]["type"] == "kafka"
    assert cfg["source"]["config"]["connection"]["bootstrap"] == "kafka:9092"
    assert cfg["source"]["config"]["connection"]["schema_registry_url"] == (
        "http://gms:8080/schema-registry/api/"
    )
    assert cfg["source"]["config"]["topic_routes"]["mcl"] == "MetadataChangeLog_Versioned_v1"
    assert cfg["filter"]["event_type"] == "MetadataChangeLogEvent_v1"
    assert cfg["filter"]["event"]["entityType"] == "dataProduct"
    assert cfg["filter"]["event"]["aspectName"] == "ownership"
    assert cfg["action"]["type"] == "attribute_bridge_ownership_sync"
    assert cfg["datahub"]["server"] == "http://gms:8080"
    assert cfg["datahub"]["token"] == "tok"


def test_schema_registry_url_omitted_when_empty() -> None:
    """Empty ``datahub_schema_registry_url`` is not passed (SDK/env defaults apply)."""
    settings = Settings(
        datahub_schema_registry_url="",
        datahub_kafka_bootstrap_servers="localhost:9092",
    )
    cfg = build_pipeline_config_dict(settings)
    assert "schema_registry_url" not in cfg["source"]["config"]["connection"]
