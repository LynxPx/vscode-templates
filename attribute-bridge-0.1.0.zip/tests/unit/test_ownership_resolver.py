"""Unit tests for the OwnershipResolver service."""

from __future__ import annotations

from unittest.mock import MagicMock

from app.services.ownership_resolver import OwnershipResolver
from tests.conftest import (
    DATASET_A,
    DATASET_B,
    DATASET_C,
    DP_1,
    DP_2,
    GROUP_ANALYTICS,
    GROUP_MARKETING,
    GROUP_URN_ANALYTICS,
    GROUP_URN_MARKETING,
)


class TestResolveGroupDatasets:
    """Tests for OwnershipResolver.resolve_group_datasets."""

    def test_single_data_product_single_dataset(
        self,
        mock_datahub_client: MagicMock,
        ownership_resolver: OwnershipResolver,
    ) -> None:
        """A group owning one DP with one dataset produces a single-entry list."""
        mock_datahub_client.get_data_products_for_group.return_value = [DP_1]
        mock_datahub_client.get_datasets_for_data_product.return_value = [DATASET_A]

        state = ownership_resolver.resolve_group_datasets(GROUP_ANALYTICS)

        assert state.group_name == GROUP_ANALYTICS
        assert state.data_product_urns == [DP_1]
        assert state.dataset_urns == [DATASET_A]

    def test_multiple_data_products_deduplicates_datasets(
        self,
        mock_datahub_client: MagicMock,
        ownership_resolver: OwnershipResolver,
    ) -> None:
        """Datasets shared across DPs are deduplicated in the output."""
        mock_datahub_client.get_data_products_for_group.return_value = [DP_1, DP_2]
        mock_datahub_client.get_datasets_for_data_product.side_effect = [
            [DATASET_A, DATASET_B],
            [DATASET_B, DATASET_C],
        ]

        state = ownership_resolver.resolve_group_datasets(GROUP_ANALYTICS)

        assert state.data_product_urns == sorted([DP_1, DP_2])
        assert state.dataset_urns == sorted([DATASET_A, DATASET_B, DATASET_C])

    def test_no_data_products_returns_empty(
        self,
        mock_datahub_client: MagicMock,
        ownership_resolver: OwnershipResolver,
    ) -> None:
        """A group with no DP ownership returns empty lists."""
        mock_datahub_client.get_data_products_for_group.return_value = []

        state = ownership_resolver.resolve_group_datasets(GROUP_ANALYTICS)

        assert state.data_product_urns == []
        assert state.dataset_urns == []

    def test_datasets_are_sorted(
        self,
        mock_datahub_client: MagicMock,
        ownership_resolver: OwnershipResolver,
    ) -> None:
        """Output dataset URNs are lexicographically sorted."""
        mock_datahub_client.get_data_products_for_group.return_value = [DP_1]
        mock_datahub_client.get_datasets_for_data_product.return_value = [
            DATASET_C,
            DATASET_A,
            DATASET_B,
        ]

        state = ownership_resolver.resolve_group_datasets(GROUP_ANALYTICS)

        assert state.dataset_urns == sorted([DATASET_A, DATASET_B, DATASET_C])


class TestResolveAllGroups:
    """Tests for OwnershipResolver.resolve_all_groups (full reconciliation)."""

    def test_multiple_groups_across_data_products(
        self,
        mock_datahub_client: MagicMock,
        ownership_resolver: OwnershipResolver,
    ) -> None:
        """Multiple groups owning different DPs each get their own state."""
        mock_datahub_client.list_all_data_products.return_value = [DP_1, DP_2]
        mock_datahub_client.get_data_product_group_owners.side_effect = [
            [GROUP_URN_ANALYTICS],
            [GROUP_URN_MARKETING],
        ]
        mock_datahub_client.get_datasets_for_data_product.side_effect = [
            [DATASET_A, DATASET_B],
            [DATASET_C],
        ]

        states = ownership_resolver.resolve_all_groups()

        assert len(states) == 2
        analytics = next(s for s in states if s.group_name == GROUP_ANALYTICS)
        marketing = next(s for s in states if s.group_name == GROUP_MARKETING)
        assert analytics.dataset_urns == sorted([DATASET_A, DATASET_B])
        assert marketing.dataset_urns == [DATASET_C]

    def test_no_data_products_returns_empty(
        self,
        mock_datahub_client: MagicMock,
        ownership_resolver: OwnershipResolver,
    ) -> None:
        """An empty catalog produces no group states."""
        mock_datahub_client.list_all_data_products.return_value = []

        states = ownership_resolver.resolve_all_groups()

        assert states == []

    def test_shared_data_product_between_groups(
        self,
        mock_datahub_client: MagicMock,
        ownership_resolver: OwnershipResolver,
    ) -> None:
        """A single DP owned by two groups appears in both states."""
        mock_datahub_client.list_all_data_products.return_value = [DP_1]
        mock_datahub_client.get_data_product_group_owners.return_value = [
            GROUP_URN_ANALYTICS,
            GROUP_URN_MARKETING,
        ]
        mock_datahub_client.get_datasets_for_data_product.return_value = [
            DATASET_A,
            DATASET_B,
        ]

        states = ownership_resolver.resolve_all_groups()

        assert len(states) == 2
        for state in states:
            assert state.dataset_urns == sorted([DATASET_A, DATASET_B])
