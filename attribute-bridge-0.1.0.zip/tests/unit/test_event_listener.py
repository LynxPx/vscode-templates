"""Unit tests for MCL parsing (shared by Kafka and DataHub Actions paths)."""

from __future__ import annotations

from app.services.mcl_parser import parse_ownership_change_from_mcl


def _make_mcl(
    entity_type: str = "dataProduct",
    aspect_name: str = "ownership",
    entity_urn: str = "urn:li:dataProduct:dp1",
    change_type: str = "UPSERT",
    current_owners: list[dict[str, str]] | None = None,
    previous_owners: list[dict[str, str]] | None = None,
) -> dict:
    """Build a minimal MCL payload for testing."""
    mcl: dict = {
        "entityType": entity_type,
        "entityUrn": entity_urn,
        "aspectName": aspect_name,
        "changeType": change_type,
    }
    if current_owners is not None:
        mcl["aspect"] = {"json": {"owners": current_owners}}
    if previous_owners is not None:
        mcl["previousAspectValue"] = {"json": {"owners": previous_owners}}
    return mcl


class TestParseMcl:
    """Tests for :func:`parse_ownership_change_from_mcl`."""

    def test_valid_ownership_event(self) -> None:
        """A valid ownership MCL with corp-group owners is parsed correctly."""
        mcl = _make_mcl(
            current_owners=[{"owner": "urn:li:corpGroup:analytics", "type": "DATAOWNER"}],
        )

        event = parse_ownership_change_from_mcl(mcl)

        assert event is not None
        assert event.entity_urn == "urn:li:dataProduct:dp1"
        assert event.affected_group_urns == ["urn:li:corpGroup:analytics"]

    def test_ignores_non_dataproduct(self) -> None:
        """Events on non-dataProduct entities are skipped."""
        mcl = _make_mcl(
            entity_type="dataset",
            current_owners=[{"owner": "urn:li:corpGroup:analytics"}],
        )

        assert parse_ownership_change_from_mcl(mcl) is None

    def test_ignores_non_ownership_aspect(self) -> None:
        """Events on non-ownership aspects are skipped."""
        mcl = _make_mcl(
            aspect_name="status",
            current_owners=[{"owner": "urn:li:corpGroup:analytics"}],
        )

        assert parse_ownership_change_from_mcl(mcl) is None

    def test_ignores_non_group_owners(self) -> None:
        """Events where no corp-group appears in owners are skipped."""
        mcl = _make_mcl(
            current_owners=[{"owner": "urn:li:corpuser:alice", "type": "DATAOWNER"}],
        )

        assert parse_ownership_change_from_mcl(mcl) is None

    def test_collects_groups_from_current_and_previous(self) -> None:
        """Groups from both current and previous aspect values are included."""
        mcl = _make_mcl(
            current_owners=[{"owner": "urn:li:corpGroup:new-team"}],
            previous_owners=[{"owner": "urn:li:corpGroup:old-team"}],
        )

        event = parse_ownership_change_from_mcl(mcl)

        assert event is not None
        assert set(event.affected_group_urns) == {
            "urn:li:corpGroup:new-team",
            "urn:li:corpGroup:old-team",
        }

    def test_deduplicates_group_urns(self) -> None:
        """A group appearing in both current and previous is included once."""
        mcl = _make_mcl(
            current_owners=[{"owner": "urn:li:corpGroup:analytics"}],
            previous_owners=[{"owner": "urn:li:corpGroup:analytics"}],
        )

        event = parse_ownership_change_from_mcl(mcl)

        assert event is not None
        assert event.affected_group_urns == ["urn:li:corpGroup:analytics"]

    def test_handles_missing_aspect_gracefully(self) -> None:
        """An MCL with no aspect or previousAspectValue is skipped."""
        mcl = _make_mcl()

        assert parse_ownership_change_from_mcl(mcl) is None
