"""Unit tests for the KeycloakSyncService."""

from __future__ import annotations

from unittest.mock import MagicMock

from app.services.group_mapper import ConfigurableGroupNameMapper
from app.services.keycloak_sync import KeycloakSyncService
from tests.conftest import DATASET_A, DATASET_B, GROUP_ANALYTICS, GROUP_MARKETING


class TestSyncGroupAccess:
    """Tests for KeycloakSyncService.sync_group_access."""

    def test_calls_client_with_correct_group_and_urns(
        self,
        mock_keycloak_client: MagicMock,
        keycloak_sync: KeycloakSyncService,
    ) -> None:
        """Verify the client receives the correct group name and URN list."""
        urns = [DATASET_A, DATASET_B]

        keycloak_sync.sync_group_access(GROUP_ANALYTICS, urns)

        mock_keycloak_client.update_group_allowed_access.assert_called_once_with(
            GROUP_ANALYTICS, urns
        )

    def test_empty_urns_clears_access(
        self,
        mock_keycloak_client: MagicMock,
        keycloak_sync: KeycloakSyncService,
    ) -> None:
        """An empty URN list should still be written (clears the attribute)."""
        keycloak_sync.sync_group_access(GROUP_ANALYTICS, [])

        mock_keycloak_client.update_group_allowed_access.assert_called_once_with(
            GROUP_ANALYTICS, []
        )

    def test_group_name_mapping_applied(
        self,
        mock_keycloak_client: MagicMock,
    ) -> None:
        """When a mapping is configured, the Keycloak group name is translated."""
        mapper = ConfigurableGroupNameMapper({"dh-analytics": "kc-analytics"})
        svc = KeycloakSyncService(mock_keycloak_client, mapper)

        svc.sync_group_access("dh-analytics", [DATASET_A])

        mock_keycloak_client.update_group_allowed_access.assert_called_once_with(
            "kc-analytics", [DATASET_A]
        )


class TestSyncAllGroups:
    """Tests for KeycloakSyncService.sync_all_groups."""

    def test_syncs_multiple_groups(
        self,
        mock_keycloak_client: MagicMock,
        keycloak_sync: KeycloakSyncService,
    ) -> None:
        """All provided groups are synced, results returned for each."""
        mapping = {
            GROUP_ANALYTICS: [DATASET_A, DATASET_B],
            GROUP_MARKETING: [DATASET_B],
        }

        results = keycloak_sync.sync_all_groups(mapping)

        assert len(results) == 2
        assert results[GROUP_ANALYTICS] is None
        assert results[GROUP_MARKETING] is None
        assert mock_keycloak_client.update_group_allowed_access.call_count == 2

    def test_captures_individual_failures(
        self,
        mock_keycloak_client: MagicMock,
        keycloak_sync: KeycloakSyncService,
    ) -> None:
        """Failure on one group does not prevent others from syncing."""
        mock_keycloak_client.update_group_allowed_access.side_effect = [
            ValueError("not found"),
            None,
        ]
        mapping = {
            GROUP_ANALYTICS: [DATASET_A],
            GROUP_MARKETING: [DATASET_B],
        }

        results = keycloak_sync.sync_all_groups(mapping)

        assert results[GROUP_ANALYTICS] is not None
        assert "not found" in results[GROUP_ANALYTICS]
        assert results[GROUP_MARKETING] is None
