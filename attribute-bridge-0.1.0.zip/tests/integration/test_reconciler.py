"""Integration-style tests for the Reconciler with all external clients mocked.

These tests verify that the end-to-end resolve→sync pipeline produces
correct downstream state for both event-driven and full-reconciliation paths.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from app.models.events import ChangeType, OwnershipChangeEvent
from app.services.reconciler import Reconciler
from tests.conftest import (
    DATASET_A,
    DATASET_B,
    DATASET_C,
    DP_1,
    DP_2,
    GROUP_ANALYTICS,
    GROUP_URN_ANALYTICS,
    GROUP_URN_MARKETING,
)

# ------------------------------------------------------------------
# Event-driven tests
# ------------------------------------------------------------------


class TestHandleOwnershipChange:
    """End-to-end tests for the event-driven sync path."""

    @pytest.mark.asyncio
    async def test_add_event_syncs_correct_datasets(
        self,
        mock_datahub_client: MagicMock,
        mock_keycloak_client: MagicMock,
        mock_k8s_client: MagicMock,
        reconciler: Reconciler,
    ) -> None:
        """Adding a group as DP owner syncs the DP's datasets to Keycloak and OPA."""
        mock_datahub_client.get_data_products_for_group.return_value = [DP_1]
        mock_datahub_client.get_datasets_for_data_product.return_value = [
            DATASET_A,
            DATASET_B,
        ]
        mock_datahub_client.list_all_data_products.return_value = [DP_1]
        mock_datahub_client.get_data_product_group_owners.return_value = [GROUP_URN_ANALYTICS]
        mock_k8s_client.read_policy_key.return_value = None

        event = OwnershipChangeEvent(
            entity_urn=DP_1,
            entity_type="dataProduct",
            aspect_name="ownership",
            change_type=ChangeType.UPSERT,
            affected_group_urns=[GROUP_URN_ANALYTICS],
        )

        results = await reconciler.handle_ownership_change(event)

        assert len(results) == 1
        assert results[0].group_name == GROUP_ANALYTICS
        assert results[0].keycloak_synced is True
        mock_keycloak_client.update_group_allowed_access.assert_called_once_with(
            GROUP_ANALYTICS, sorted([DATASET_A, DATASET_B])
        )
        mock_k8s_client.write_policy_data.assert_called_once()

    @pytest.mark.asyncio
    async def test_remove_event_recomputes_remaining_access(
        self,
        mock_datahub_client: MagicMock,
        mock_keycloak_client: MagicMock,
        mock_k8s_client: MagicMock,
        reconciler: Reconciler,
    ) -> None:
        """Removing a group from one DP does NOT blindly clear all access.

        The group still owns DP_2, so its datasets remain in the sync output.
        """
        mock_datahub_client.get_data_products_for_group.return_value = [DP_2]
        mock_datahub_client.get_datasets_for_data_product.side_effect = [
            [DATASET_C],  # single-group resolve for analytics
            [DATASET_A, DATASET_B],  # OPA rebuild: datasets for DP_1
            [DATASET_C],  # OPA rebuild: datasets for DP_2
        ]
        mock_datahub_client.list_all_data_products.return_value = [DP_1, DP_2]
        mock_datahub_client.get_data_product_group_owners.side_effect = [
            [GROUP_URN_MARKETING],  # DP_1 now owned by marketing only
            [GROUP_URN_ANALYTICS],  # DP_2 still owned by analytics
        ]
        mock_k8s_client.read_policy_key.return_value = None

        event = OwnershipChangeEvent(
            entity_urn=DP_1,
            entity_type="dataProduct",
            aspect_name="ownership",
            change_type=ChangeType.UPSERT,
            affected_group_urns=[GROUP_URN_ANALYTICS],
        )

        results = await reconciler.handle_ownership_change(event)

        assert results[0].datasets_count == 1
        mock_keycloak_client.update_group_allowed_access.assert_called_once_with(
            GROUP_ANALYTICS, [DATASET_C]
        )


# ------------------------------------------------------------------
# Full reconciliation tests
# ------------------------------------------------------------------


class TestReconcile:
    """End-to-end tests for full periodic reconciliation."""

    @pytest.mark.asyncio
    async def test_full_reconciliation_syncs_all_groups(
        self,
        mock_datahub_client: MagicMock,
        mock_keycloak_client: MagicMock,
        mock_k8s_client: MagicMock,
        reconciler: Reconciler,
    ) -> None:
        """Full reconciliation resolves and syncs every group."""
        mock_datahub_client.list_all_data_products.return_value = [DP_1, DP_2]
        mock_datahub_client.get_data_product_group_owners.side_effect = [
            [GROUP_URN_ANALYTICS],
            [GROUP_URN_MARKETING],
        ]
        mock_datahub_client.get_datasets_for_data_product.side_effect = [
            [DATASET_A, DATASET_B],  # first resolve_all call
            [DATASET_C],
            [DATASET_A, DATASET_B],  # OPA rebuild
            [DATASET_C],
        ]
        mock_k8s_client.read_policy_key.return_value = None

        results = await reconciler.reconcile()

        assert len(results) == 2
        assert mock_keycloak_client.update_group_allowed_access.call_count == 2

    @pytest.mark.asyncio
    async def test_dry_run_skips_writes(
        self,
        mock_datahub_client: MagicMock,
        mock_keycloak_client: MagicMock,
        mock_k8s_client: MagicMock,
        reconciler: Reconciler,
        settings: MagicMock,
    ) -> None:
        """Dry-run mode resolves state but does not call Keycloak or K8s."""
        from app.config import Settings as RealSettings

        dry_settings = RealSettings(
            datahub_url="http://localhost:8080",
            keycloak_url="http://localhost:8180",
            keycloak_realm="test",
            keycloak_client_id="test",
            keycloak_client_secret="test",
            dry_run=True,
        )
        from app.services.configmap_sync import ConfigMapSyncService
        from app.services.group_mapper import DirectGroupNameMapper
        from app.services.keycloak_sync import KeycloakSyncService
        from app.services.opa_policy_builder import OpaPolicyBuilder
        from app.services.ownership_resolver import OwnershipResolver

        dry_reconciler = Reconciler(
            ownership_resolver=OwnershipResolver(mock_datahub_client),
            keycloak_sync=KeycloakSyncService(mock_keycloak_client, DirectGroupNameMapper()),
            configmap_sync=ConfigMapSyncService(mock_k8s_client, OpaPolicyBuilder()),
            policy_builder=OpaPolicyBuilder(),
            group_mapper=DirectGroupNameMapper(),
            settings=dry_settings,
        )

        mock_datahub_client.list_all_data_products.return_value = [DP_1]
        mock_datahub_client.get_data_product_group_owners.return_value = [GROUP_URN_ANALYTICS]
        mock_datahub_client.get_datasets_for_data_product.return_value = [DATASET_A]

        results = await dry_reconciler.reconcile()

        assert all(r.dry_run for r in results)
        mock_keycloak_client.update_group_allowed_access.assert_not_called()
        mock_k8s_client.write_policy_data.assert_not_called()

    @pytest.mark.asyncio
    async def test_idempotent_reconciliation(
        self,
        mock_datahub_client: MagicMock,
        mock_keycloak_client: MagicMock,
        mock_k8s_client: MagicMock,
        reconciler: Reconciler,
    ) -> None:
        """Running reconciliation twice with the same data produces identical calls."""
        mock_datahub_client.list_all_data_products.return_value = [DP_1]
        mock_datahub_client.get_data_product_group_owners.return_value = [GROUP_URN_ANALYTICS]
        mock_datahub_client.get_datasets_for_data_product.return_value = [DATASET_A, DATASET_B]
        mock_k8s_client.read_policy_key.return_value = None

        results_1 = await reconciler.reconcile()

        mock_k8s_client.read_policy_key.return_value = None
        results_2 = await reconciler.reconcile()

        assert results_1[0].datasets_count == results_2[0].datasets_count
