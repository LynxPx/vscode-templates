"""FastAPI application entry point with lifespan management.

Starts the Kafka event listener (if configured) and the periodic
reconciliation loop alongside the HTTP server.
"""

from __future__ import annotations

import asyncio
import contextlib
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import structlog
from fastapi import FastAPI

from app.api.routes import router
from app.dependencies import get_reconciler, get_settings
from app.log_config import setup_logging
from app.services.event_listener import KafkaEventListener
from app.services.reconciler import Reconciler
from app.services.startup_dependency_checks import (
    log_startup_connection_summary,
    run_dependency_probes_at_startup,
)

logger = structlog.get_logger(__name__)


async def _reconciliation_loop(reconciler: Reconciler, interval: int) -> None:
    """Run full reconciliation on a fixed schedule.

    Args:
        reconciler: The reconciler instance.
        interval: Seconds between runs.
    """
    while True:
        try:
            logger.info("periodic reconciliation starting")
            results = await reconciler.reconcile()
            logger.info(
                "periodic reconciliation finished",
                groups=len(results),
                errors=sum(1 for r in results if r.errors),
            )
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("periodic reconciliation failed")
        await asyncio.sleep(interval)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Manage startup and shutdown of background tasks.

    Starts:
    - Dependency connectivity probes (DataHub, Keycloak, Kubernetes); a readable summary
      is logged after startup; failures do not abort boot.
    - Kafka event listener (when ``datahub_event_source == "kafka"``).
    - Periodic reconciliation loop (when ``reconcile_enabled`` is ``True``).

    Args:
        app: The FastAPI application instance.
    """
    settings = get_settings()
    setup_logging(settings.log_level)

    logger.info(
        "configuration loaded",
        datahub_url=settings.datahub_url,
        datahub_event_source=settings.datahub_event_source,
        keycloak_url=settings.keycloak_url,
        keycloak_realm=settings.keycloak_realm,
        keycloak_group_match_mode=settings.keycloak_group_match_mode,
        k8s_namespace=settings.k8s_namespace,
        k8s_configmap_name=settings.k8s_configmap_name,
        k8s_in_cluster=settings.k8s_in_cluster,
        reconcile_enabled=settings.reconcile_enabled,
        reconcile_interval_seconds=settings.reconcile_interval_seconds,
        dry_run=settings.dry_run,
        log_level=settings.log_level,
        readiness_strict=settings.readiness_strict,
    )

    dependency_probe_results = await run_dependency_probes_at_startup()

    reconciler = get_reconciler()

    event_listener: KafkaEventListener | None = None
    actions_runner: Any = None
    reconcile_task: asyncio.Task[None] | None = None

    if settings.datahub_event_source == "kafka":
        event_listener = KafkaEventListener(
            settings=settings,
            callback=reconciler.handle_ownership_change,  # type: ignore[arg-type]
        )
        try:
            await event_listener.start()
        except Exception:
            logger.exception("failed to start kafka event listener — continuing without it")
            event_listener = None
    elif settings.datahub_event_source == "actions":
        try:
            from app.services.datahub_actions_pipeline import EmbeddedDataHubActionsRunner
        except ImportError:
            logger.exception(
                "DATAHUB_EVENT_SOURCE=actions requires optional dependencies: "
                "pip install 'attribute-bridge[actions]'",
            )
        else:
            actions_runner = EmbeddedDataHubActionsRunner(settings)
            try:
                actions_runner.start()
            except Exception:
                logger.exception(
                    "failed to start embedded datahub actions pipeline — continuing without it",
                )
                actions_runner = None
    else:
        logger.info(
            "real-time event listener disabled, running in polling/reconciliation-only mode",
            event_source=settings.datahub_event_source,
        )

    if settings.reconcile_enabled:
        reconcile_task = asyncio.create_task(
            _reconciliation_loop(reconciler, settings.reconcile_interval_seconds)
        )
        logger.info(
            "reconciliation loop started",
            interval_seconds=settings.reconcile_interval_seconds,
        )

    dep_ok = all(r.ok for r in dependency_probe_results)
    kafka_required = settings.datahub_event_source == "kafka"
    actions_required = settings.datahub_event_source == "actions"
    pipeline_ok = True
    if kafka_required:
        pipeline_ok = event_listener is not None
    elif actions_required:
        pipeline_ok = actions_runner is not None

    app.state.ready_for_traffic = dep_ok and pipeline_ok
    if settings.readiness_strict and not app.state.ready_for_traffic:
        logger.error(
            "strict readiness: service not ready for traffic",
            dependencies_ok=dep_ok,
            event_pipeline_ok=pipeline_ok,
            datahub_event_source=settings.datahub_event_source,
        )

    logger.info("attribute-bridge started")

    async def _log_connection_summary_after_uvicorn_startup() -> None:
        """Defer summary until after Uvicorn's own startup log lines."""
        await asyncio.sleep(0)
        log_startup_connection_summary(dependency_probe_results)

    asyncio.create_task(_log_connection_summary_after_uvicorn_startup())

    yield

    logger.info("shutting down attribute-bridge")
    if reconcile_task and not reconcile_task.done():
        reconcile_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await reconcile_task

    if event_listener:
        await event_listener.stop()

    if actions_runner is not None:
        actions_runner.stop()

    logger.info("attribute-bridge stopped")


def create_app() -> FastAPI:
    """Application factory.

    Returns:
        Configured FastAPI application with routes and lifespan management.
    """
    app = FastAPI(
        title="AttributeBridge",
        description="Syncs DataHub ownership to Keycloak group attributes and OPA/Trino policy",
        version="0.1.0",
        lifespan=lifespan,
    )
    app.include_router(router)
    return app


app = create_app()
