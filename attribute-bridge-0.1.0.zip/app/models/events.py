"""Event models for DataHub MetadataChangeLog consumption."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field


class ChangeType(StrEnum):
    """DataHub MetadataChangeLog change types."""

    UPSERT = "UPSERT"
    DELETE = "DELETE"


class OwnershipChangeEvent(BaseModel):
    """Parsed ownership-change event for a Data Product.

    Attributes:
        entity_urn: URN of the Data Product whose ownership changed.
        entity_type: DataHub entity type (always ``dataProduct`` after filtering).
        aspect_name: The aspect that changed (always ``ownership`` after filtering).
        change_type: Whether the aspect was upserted or deleted.
        affected_group_urns: Union of group URNs from current and previous
            ownership — every group that may need state recomputation.
    """

    entity_urn: str
    entity_type: str
    aspect_name: str
    change_type: ChangeType
    affected_group_urns: list[str] = Field(default_factory=list)
