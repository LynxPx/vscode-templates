"""Core domain models representing ownership state and sync results."""

from __future__ import annotations

from pydantic import BaseModel, Field


class GroupOwnershipState(BaseModel):
    """Fully resolved ownership state for a single group.

    Attributes:
        group_name: DataHub corp-group name (without the URN prefix).
        data_product_urns: Sorted list of Data Product URNs the group owns.
        dataset_urns: Sorted, deduplicated dataset URNs across all owned Data Products.
    """

    group_name: str
    data_product_urns: list[str] = Field(default_factory=list)
    dataset_urns: list[str] = Field(default_factory=list)


class DatasetAccessMapping(BaseModel):
    """Aggregate mapping from group names to their allowed dataset URNs.

    Attributes:
        mappings: ``group_name -> sorted list of dataset URNs``.
    """

    mappings: dict[str, list[str]] = Field(default_factory=dict)

    @classmethod
    def from_states(cls, states: list[GroupOwnershipState]) -> DatasetAccessMapping:
        """Build a mapping from a list of resolved group ownership states.

        Args:
            states: Ownership states to aggregate.

        Returns:
            A new DatasetAccessMapping instance.
        """
        return cls(mappings={s.group_name: s.dataset_urns for s in states})


class SyncResult(BaseModel):
    """Outcome of synchronising a single group's access to downstream systems.

    Attributes:
        group_name: The group that was synced.
        datasets_count: Number of dataset URNs in the resolved state.
        keycloak_synced: True if Keycloak was updated successfully.
        opa_synced: True if the OPA ConfigMap was updated successfully.
        dry_run: True if the sync was a no-op due to dry-run mode.
        errors: Human-readable error messages for any failures.
    """

    group_name: str
    datasets_count: int = 0
    keycloak_synced: bool = False
    opa_synced: bool = False
    dry_run: bool = False
    errors: list[str] = Field(default_factory=list)
