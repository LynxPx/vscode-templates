"""Parse DataHub Metadata Change Log payloads into domain events.

Used by both the lightweight ``aiokafka`` consumer (JSON payloads) and the
embedded DataHub Actions pipeline (typed ``MetadataChangeLogEvent`` serialized
via ``as_json()``).
"""

from __future__ import annotations

import json
from typing import Any

import structlog

from app.models.events import ChangeType, OwnershipChangeEvent

logger = structlog.get_logger(__name__)

CORP_GROUP_URN_PREFIX = "urn:li:corpGroup:"


def _owner_urn_from_entry(owner_entry: dict[str, Any]) -> str:
    """Extract a corp-user / corp-group URN string from an ownership entry dict.

    Args:
        owner_entry: One element of an ownership ``owners`` list.

    Returns:
        Owner URN string, or empty string if missing / unsupported shape.
    """
    raw = owner_entry.get("owner")
    if isinstance(raw, str):
        return raw
    if isinstance(raw, dict):
        urn = raw.get("urn") or raw.get("entityUrn")
        if isinstance(urn, str):
            return urn
    return ""


def parse_ownership_change_from_mcl(raw: dict[str, Any]) -> OwnershipChangeEvent | None:
    """Parse an MCL body dict into an ownership change event, or ``None`` if irrelevant.

    Filtering criteria:
    - ``entityType`` must be ``dataProduct``
    - ``aspectName`` must be ``ownership``
    - At least one corp-group owner must appear in either the current or
      previous aspect value.

    Args:
        raw: MCL payload as a plain dict (Kafka JSON or ``json.loads(event.as_json())``).

    Returns:
        Parsed event or ``None`` when the message does not match filters.
    """
    entity_type = raw.get("entityType", "")
    aspect_name = raw.get("aspectName", "")

    if entity_type != "dataProduct" or aspect_name != "ownership":
        return None

    entity_urn = raw.get("entityUrn", "")
    change_type_raw = raw.get("changeType", "UPSERT")

    affected_groups: set[str] = set()
    for key in ("aspect", "previousAspectValue"):
        aspect_wrapper = raw.get(key)
        if not isinstance(aspect_wrapper, dict):
            continue
        aspect_data = aspect_wrapper.get("json", aspect_wrapper)
        if not isinstance(aspect_data, dict):
            continue
        for owner in aspect_data.get("owners", []):
            if not isinstance(owner, dict):
                continue
            owner_urn = _owner_urn_from_entry(owner)
            if owner_urn.startswith(CORP_GROUP_URN_PREFIX):
                affected_groups.add(owner_urn)

    if not affected_groups:
        return None

    try:
        change_type = ChangeType(change_type_raw)
    except ValueError:
        logger.warning(
            "unknown MCL changeType, defaulting to UPSERT",
            change_type_raw=change_type_raw,
            entity_urn=entity_urn,
        )
        change_type = ChangeType.UPSERT

    return OwnershipChangeEvent(
        entity_urn=entity_urn,
        entity_type=entity_type,
        aspect_name=aspect_name,
        change_type=change_type,
        affected_group_urns=sorted(affected_groups),
    )


def ownership_event_from_actions_envelope(event: Any) -> OwnershipChangeEvent | None:
    """Parse a DataHub Actions :class:`EventEnvelope` into our domain event.

    Args:
        event: ``datahub_actions.event.event_envelope.EventEnvelope``.

    Returns:
        Parsed :class:`OwnershipChangeEvent` or ``None``.
    """
    from datahub_actions.event.event_registry import METADATA_CHANGE_LOG_EVENT_V1_TYPE

    if event.event_type != METADATA_CHANGE_LOG_EVENT_V1_TYPE:
        return None
    raw = json.loads(event.event.as_json())
    return parse_ownership_change_from_mcl(raw)
