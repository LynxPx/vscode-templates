"""Startup connectivity probes for external dependencies.

Probes run early in lifespan; a human-readable summary is logged after the app
is fully wired so operators see DataHub, Keycloak, and Kubernetes status in one place.

When ``stderr`` is a TTY, summary lines use :mod:`colorama` (ANSI on Unix, converted
streams on Windows). Plain text is used when stderr is not a TTY so JSON logs stay clean.
"""

from __future__ import annotations

import asyncio
import sys
from collections.abc import Callable, Iterable
from dataclasses import dataclass

import structlog
from colorama import Fore, Style, init

logger = structlog.get_logger(__name__)

_colorama_initialized = False


def _ensure_colorama() -> None:
    """Call :func:`colorama.init` once so styled output works on Windows and Unix.

    Side effects:
        Initializes Colorama's stdout/stderr wrappers on first use.
    """
    global _colorama_initialized
    if _colorama_initialized:
        return
    init()
    _colorama_initialized = True


def _stderr_supports_color() -> bool:
    """Return True if we should emit color sequences for stderr.

    Returns:
        Whether ``sys.stderr`` appears to be a TTY.
    """
    return sys.stderr.isatty()


def _paint_component_name(name: str) -> str:
    """Style a dependency label for terminal output using Colorama.

    Args:
        name: Display name (e.g. ``DataHub``).

    Returns:
        Plain *name* when color is disabled; bold bright cyan otherwise.
    """
    if not _stderr_supports_color():
        return name
    _ensure_colorama()
    return f"{Style.BRIGHT}{Fore.CYAN}{name}{Style.RESET_ALL}"


def _paint_success_phrase(text: str) -> str:
    """Style a success status fragment (e.g. ``connection successful``).

    Args:
        text: Phrase to highlight.

    Returns:
        Plain *text* or bright green text.
    """
    if not _stderr_supports_color():
        return text
    _ensure_colorama()
    return f"{Fore.LIGHTGREEN_EX}{text}{Style.RESET_ALL}"


def _paint_failure_phrase(text: str) -> str:
    """Style a failure status or error detail for terminal output.

    Args:
        text: Phrase or error summary.

    Returns:
        Plain *text* or bright red text.
    """
    if not _stderr_supports_color():
        return text
    _ensure_colorama()
    return f"{Fore.LIGHTRED_EX}{text}{Style.RESET_ALL}"


def _paint_dim(text: str) -> str:
    """Style secondary text (banners, success details).

    Args:
        text: Secondary content.

    Returns:
        Plain *text* or dim text.
    """
    if not _stderr_supports_color():
        return text
    _ensure_colorama()
    return f"{Style.DIM}{text}{Style.RESET_ALL}"


def _paint_banner_line(text: str) -> str:
    """Style a horizontal rule in the summary block.

    Args:
        text: Banner characters.

    Returns:
        Plain *text* or dim yellow-tinted rule.
    """
    if not _stderr_supports_color():
        return text
    _ensure_colorama()
    return f"{Style.DIM}{Fore.LIGHTYELLOW_EX}{text}{Style.RESET_ALL}"


@dataclass(frozen=True)
class DependencyProbeResult:
    """Outcome of a single startup connectivity probe to an external system.

    Attributes:
        label: Short display name (e.g. ``DataHub``).
        ok: Whether the probe succeeded.
        detail: On success, text from :meth:`~verify_connection`; on failure, error summary.
    """

    label: str
    ok: bool
    detail: str

    def summary_line(self) -> str:
        """Return one plain-text sentence for this probe (no ANSI codes).

        Returns:
            Either a success line with detail or a failure line with the error summary.
        """
        if self.ok:
            return f"{self.label} connection successful — {self.detail}"
        return f"{self.label} connection failed — {self.detail}"

    def display_line(self) -> str:
        """Return a sentence for logging, with Colorama when stderr is a TTY.

        Component names use bold cyan; ``connection successful`` is green;
        ``connection failed`` and error text are red; trailing detail on success
        is dimmed for contrast.

        Returns:
            Plain text (same wording as :meth:`summary_line`) when stderr is not a TTY;
            otherwise styled text via Colorama.
        """
        name = _paint_component_name(self.label)
        if self.ok:
            status = _paint_success_phrase("connection successful")
            detail = _paint_dim(f" — {self.detail}")
            return f"{name} {status}{detail}"
        status = _paint_failure_phrase("connection failed")
        reason = _paint_failure_phrase(self.detail)
        return f"{name} {status} — {reason}"


async def run_dependency_probes_at_startup() -> list[DependencyProbeResult]:
    """Probe DataHub, Keycloak, and Kubernetes without logging per probe.

    Each check runs in a worker thread to avoid blocking the event loop during
    synchronous HTTP/API calls. Failures are captured in the returned results;
    they do not raise.

    Returns:
        Three :class:`DependencyProbeResult` instances in probe order.

    Side effects:
        Constructs and caches singleton clients via :mod:`app.dependencies` on
        first access (same instances used by the reconciler).
    """
    from app.dependencies import get_datahub_client, get_k8s_client, get_keycloak_client

    probes: list[tuple[str, Callable[[], str]]] = [
        ("DataHub", lambda: get_datahub_client().verify_connection()),
        ("Keycloak", lambda: get_keycloak_client().verify_connection()),
        ("Kubernetes", lambda: get_k8s_client().verify_connection()),
    ]

    results: list[DependencyProbeResult] = []
    for label, fn in probes:
        try:
            detail = await asyncio.to_thread(fn)
            results.append(DependencyProbeResult(label=label, ok=True, detail=detail))
        except Exception as exc:
            err = f"{type(exc).__name__}: {exc}"
            results.append(DependencyProbeResult(label=label, ok=False, detail=err))
    return results


def log_startup_connection_summary(results: Iterable[DependencyProbeResult]) -> None:
    """Log a bordered, one-line-per-dependency summary for operators.

    Uses Colorama when ``stderr`` is a TTY; see :meth:`DependencyProbeResult.display_line`.

    Args:
        results: Probe outcomes from :func:`run_dependency_probes_at_startup`.
    """
    log = structlog.get_logger(__name__)
    log.info(_paint_banner_line("────────────────── External connections ──────────────────"))
    for r in results:
        log.info(r.display_line())
    log.info(_paint_banner_line("────────────────────────────────────────────────────────────"))
