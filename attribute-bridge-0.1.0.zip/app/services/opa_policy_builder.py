"""Builds deterministic OPA policy data from group-to-dataset mappings.

The generated JSON document is designed for consumption by OPA/Trino and
stored in a Kubernetes ConfigMap.  Output is sorted by group name and
dataset URN so that identical logical state always produces identical bytes
(important for diffing, caching, and change detection).

The policy-rendering strategy is encapsulated here so it can be swapped
for a different OPA data model in the future without touching the rest of
the codebase.
"""

from __future__ import annotations

import json

import structlog

from app.models.domain import GroupOwnershipState

logger = structlog.get_logger(__name__)


class OpaPolicyBuilder:
    """Renders a JSON policy document from resolved group ownership states.

    Example output::

        {
          "groups": {
            "analytics": {
              "allowed_access": [
                "urn:li:dataset:(urn:li:dataPlatform:trino,sales.customers,PROD)",
                "urn:li:dataset:(urn:li:dataPlatform:trino,sales.orders,PROD)"
              ]
            }
          }
        }
    """

    def build_policy(self, states: list[GroupOwnershipState]) -> str:
        """Render the full OPA policy data document.

        Args:
            states: Resolved ownership states (one per group).

        Returns:
            Deterministically sorted and indented JSON string.
        """
        policy: dict[str, dict[str, dict[str, list[str]]]] = {"groups": {}}
        for state in sorted(states, key=lambda s: s.group_name):
            policy["groups"][state.group_name] = {
                "allowed_access": list(state.dataset_urns),
            }
        result = json.dumps(policy, indent=2, sort_keys=True) + "\n"
        logger.debug(
            "built policy document",
            groups=len(states),
            total_datasets=sum(len(s.dataset_urns) for s in states),
            policy_size=len(result),
        )
        return result

    @staticmethod
    def validate_policy(policy_json: str) -> bool:
        """Check that a policy JSON string conforms to the expected schema.

        Validates structure only -- does not verify URN format or existence.
        Every validation failure is logged with the specific reason.

        Args:
            policy_json: JSON string to validate.

        Returns:
            ``True`` if the document is well-formed and structurally correct.
        """
        try:
            data = json.loads(policy_json)
        except (json.JSONDecodeError, TypeError) as exc:
            logger.warning("policy validation failed: invalid JSON", error=str(exc))
            return False

        if not isinstance(data, dict):
            logger.warning("policy validation failed: root is not a dict", type=type(data).__name__)
            return False

        if "groups" not in data:
            logger.warning("policy validation failed: missing 'groups' key")
            return False

        groups = data["groups"]
        if not isinstance(groups, dict):
            logger.warning(
                "policy validation failed: 'groups' is not a dict",
                type=type(groups).__name__,
            )
            return False

        for group_name, group_data in groups.items():
            if not isinstance(group_name, str):
                logger.warning(
                    "policy validation failed: group key is not a string",
                    key=repr(group_name),
                )
                return False
            if not isinstance(group_data, dict):
                logger.warning(
                    "policy validation failed: group value is not a dict",
                    group=group_name,
                    type=type(group_data).__name__,
                )
                return False
            if "allowed_access" not in group_data:
                logger.warning(
                    "policy validation failed: missing 'allowed_access'",
                    group=group_name,
                )
                return False
            allowed = group_data["allowed_access"]
            if not isinstance(allowed, list):
                logger.warning(
                    "policy validation failed: 'allowed_access' is not a list",
                    group=group_name,
                    type=type(allowed).__name__,
                )
                return False
            for i, val in enumerate(allowed):
                if not isinstance(val, str):
                    logger.warning(
                        "policy validation failed: non-string value in allowed_access",
                        group=group_name,
                        index=i,
                        type=type(val).__name__,
                    )
                    return False

        logger.debug("policy validation passed", groups=len(groups))
        return True
