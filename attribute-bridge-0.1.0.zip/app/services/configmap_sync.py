"""Synchronises OPA policy data into a Kubernetes ConfigMap.

Validates the generated policy before writing and preserves the last
known-good content if validation fails, preventing corrupt policy from
reaching Trino/OPA.
"""

from __future__ import annotations

import structlog

from app.clients.k8s_client import K8sClient
from app.services.opa_policy_builder import OpaPolicyBuilder

logger = structlog.get_logger(__name__)


class ConfigMapSyncService:
    """Writes validated OPA policy JSON into a Kubernetes ConfigMap.

    Args:
        k8s_client: Client for ConfigMap operations.
        policy_builder: Used only for validation (building happens elsewhere).
    """

    def __init__(
        self,
        k8s_client: K8sClient,
        policy_builder: OpaPolicyBuilder,
    ) -> None:
        self._k8s = k8s_client
        self._policy_builder = policy_builder
        self._last_good_policy: str | None = None
        self._log = logger.bind(service="configmap_sync")

    def sync_policy(self, policy_json: str) -> None:
        """Validate and write policy JSON to the ConfigMap.

        If validation fails the write is skipped and the last known-good
        policy is preserved in memory (not overwritten).

        Args:
            policy_json: Serialised OPA policy JSON.

        Raises:
            ValueError: If validation fails.
        """
        self._log.debug("validating policy before write", policy_size=len(policy_json))

        if not self._policy_builder.validate_policy(policy_json):
            self._log.error(
                "refusing to write invalid policy to configmap",
                policy_size=len(policy_json),
                last_good_available=self._last_good_policy is not None,
            )
            raise ValueError("Generated OPA policy failed validation")

        self._log.debug("reading current configmap content for diff check")
        current = self._k8s.read_policy_key()
        if current is not None and current == policy_json:
            self._log.info("configmap already up-to-date, skipping write")
            return

        self._log.debug(
            "configmap content differs, writing update",
            current_size=len(current) if current else 0,
            new_size=len(policy_json),
        )
        self._k8s.write_policy_data(policy_json)
        self._last_good_policy = policy_json
        self._log.info("configmap updated with new policy", policy_size=len(policy_json))

    @property
    def last_good_policy(self) -> str | None:
        """Return the most recent successfully written policy, or ``None``."""
        return self._last_good_policy
