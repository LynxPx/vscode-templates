"""Embed the DataHub Actions framework inside this process (no YAML, no separate CLI).

`Pipeline.create` accepts the same structure as an Actions YAML file; we build
that structure in Python from :class:`~app.config.Settings`.

The Actions Kafka source uses Confluent's Avro deserializer and **requires**
Schema Registry (typically the URL exposed by DataHub GMS).  This differs
from the lightweight ``aiokafka`` + JSON path (``DATAHUB_EVENT_SOURCE=kafka``).

Install optional dependencies::

    pip install 'attribute-bridge[actions]'
"""

from __future__ import annotations

import asyncio
import threading
from typing import Any

import structlog
from datahub_actions.action.action import Action
from datahub_actions.action.action_registry import action_registry
from datahub_actions.event.event_envelope import EventEnvelope
from datahub_actions.pipeline.pipeline import Pipeline
from datahub_actions.pipeline.pipeline_config import FailureMode
from datahub_actions.pipeline.pipeline_context import PipelineContext

from app.config import Settings
from app.services.mcl_parser import ownership_event_from_actions_envelope

logger = structlog.get_logger(__name__)

ACTION_TYPE = "attribute_bridge_ownership_sync"


class OwnershipSyncAction(Action):
    """Forwards filtered MCL events to the app's :class:`~app.services.reconciler.Reconciler`.

    Registered under :data:`ACTION_TYPE` and invoked by an embedded Actions
    :class:`datahub_actions.pipeline.pipeline.Pipeline`.
    """

    @classmethod
    def create(cls, config_dict: dict[str, Any], ctx: PipelineContext) -> Action:
        """Ignore *config_dict*; the reconciler is resolved at runtime via DI.

        Args:
            config_dict: Unused (Actions framework passes pipeline YAML/dict fragment).
            ctx: Pipeline context from the Actions framework.

        Returns:
            A new action instance.
        """
        _ = config_dict, ctx
        return cls()

    def act(self, event: EventEnvelope) -> None:
        """Parse the envelope and run async reconciliation in a fresh event loop.

        The Actions pipeline runs in a worker thread without an asyncio loop,
        so :func:`asyncio.run` is appropriate here.

        Args:
            event: Envelope from the Kafka event source (post-filter).
        """
        parsed = ownership_event_from_actions_envelope(event)
        if parsed is None:
            return
        from app.dependencies import get_reconciler

        reconciler = get_reconciler()
        asyncio.run(reconciler.handle_ownership_change(parsed))

    def close(self) -> None:
        """No resources to release."""
        pass


def register_attribute_bridge_action() -> None:
    """Register :class:`OwnershipSyncAction` with the global Actions registry.

    Safe to call on every application startup (uses ``override=True``).
    """
    action_registry.register(ACTION_TYPE, OwnershipSyncAction, override=True)
    logger.debug("registered datahub action", action_type=ACTION_TYPE)


def build_pipeline_config_dict(settings: Settings) -> dict[str, Any]:
    """Build a :class:`PipelineConfig`-compatible dict from application settings.

    Args:
        settings: Loaded application settings.

    Returns:
        Dict suitable for :meth:`Pipeline.create`.
    """
    connection: dict[str, Any] = {
        "bootstrap": settings.datahub_kafka_bootstrap_servers,
    }
    if settings.datahub_schema_registry_url:
        connection["schema_registry_url"] = settings.datahub_schema_registry_url

    return {
        "name": settings.datahub_kafka_consumer_group,
        "enabled": True,
        "source": {
            "type": "kafka",
            "config": {
                "connection": connection,
                "topic_routes": {"mcl": settings.datahub_kafka_topic},
            },
        },
        "filter": {
            "event_type": "MetadataChangeLogEvent_v1",
            "event": {
                "entityType": "dataProduct",
                "aspectName": "ownership",
            },
        },
        "action": {
            "type": ACTION_TYPE,
            "config": {},
        },
        "datahub": {
            "server": settings.datahub_url,
            "token": settings.datahub_token or None,
        },
        "options": {
            "failure_mode": FailureMode.CONTINUE.value,
        },
    }


class EmbeddedDataHubActionsRunner:
    """Runs a :class:`Pipeline` in a background thread with clean shutdown."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._thread: threading.Thread | None = None
        self._pipeline: Pipeline | None = None
        self._log = logger.bind(component="embedded_datahub_actions")

    def start(self) -> None:
        """Register the custom action, create the pipeline, and start the worker thread.

        Raises:
            Exception: If pipeline creation or thread start fails.
        """
        register_attribute_bridge_action()
        cfg = build_pipeline_config_dict(self._settings)
        self._log.info(
            "starting embedded datahub actions pipeline",
            pipeline_name=cfg["name"],
            topic=cfg["source"]["config"]["topic_routes"]["mcl"],
            bootstrap=cfg["source"]["config"]["connection"]["bootstrap"],
        )
        self._log.debug("pipeline config built", config_keys=list(cfg.keys()))
        self._pipeline = Pipeline.create(cfg)
        self._thread = threading.Thread(
            target=self._run_pipeline,
            name="datahub-actions-pipeline",
            daemon=True,
        )
        self._thread.start()

    def _run_pipeline(self) -> None:
        """Blocking entry point for the worker thread."""
        assert self._pipeline is not None
        try:
            self._pipeline.run()
        except Exception:
            self._log.exception("embedded datahub actions pipeline exited with error")

    def stop(self) -> None:
        """Signal the pipeline to stop and wait for the worker thread."""
        self._log.debug("stopping embedded datahub actions pipeline")
        if self._pipeline is not None:
            try:
                self._pipeline.stop()
            except Exception:
                self._log.exception("error while stopping datahub actions pipeline")
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=60.0)
        self._log.info("embedded datahub actions pipeline stopped")
