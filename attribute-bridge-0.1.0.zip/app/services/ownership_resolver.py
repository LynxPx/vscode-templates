"""Resolves the full group-to-dataset mapping from DataHub.

Given a group name, determines every Data Product the group owns and every
dataset contained in those Data Products.  Also supports a full-scan mode
for periodic reconciliation.
"""

from __future__ import annotations

import structlog

from app.clients.datahub_client import CORP_GROUP_URN_PREFIX, DataHubClient
from app.models.domain import GroupOwnershipState

logger = structlog.get_logger(__name__)


class OwnershipResolver:
    """Computes fully-resolved ownership state from DataHub.

    Args:
        datahub_client: Client used to query DataHub's GraphQL API.
    """

    def __init__(self, datahub_client: DataHubClient) -> None:
        self._datahub = datahub_client
        self._log = logger.bind(service="ownership_resolver")

    def resolve_group_datasets(self, group_name: str) -> GroupOwnershipState:
        """Resolve all datasets a single group can access through Data Product ownership.

        Args:
            group_name: DataHub corp-group name (without URN prefix).

        Returns:
            Fully resolved :class:`GroupOwnershipState` with sorted, deduplicated URNs.
        """
        group_urn = f"{CORP_GROUP_URN_PREFIX}{group_name}"
        self._log.debug("resolving datasets for group", group=group_name)

        data_product_urns = self._datahub.get_data_products_for_group(group_urn)

        all_datasets: set[str] = set()
        for dp_urn in data_product_urns:
            datasets = self._datahub.get_datasets_for_data_product(dp_urn)
            all_datasets.update(datasets)

        state = GroupOwnershipState(
            group_name=group_name,
            data_product_urns=sorted(data_product_urns),
            dataset_urns=sorted(all_datasets),
        )
        self._log.info(
            "resolved group ownership",
            group=group_name,
            data_products=len(state.data_product_urns),
            datasets=len(state.dataset_urns),
        )
        return state

    def resolve_all_groups(self) -> list[GroupOwnershipState]:
        """Full scan: resolve ownership for every group that owns at least one Data Product.

        Iterates over all Data Products, collects their group owners, then
        resolves datasets per group.  Intended for periodic reconciliation.

        Returns:
            List of :class:`GroupOwnershipState`, one per owning group.
        """
        self._log.info("starting full ownership resolution")
        all_data_products = self._datahub.list_all_data_products()
        self._log.info("found data products", count=len(all_data_products))

        group_to_dps: dict[str, set[str]] = {}
        for dp_urn in all_data_products:
            group_urns = self._datahub.get_data_product_group_owners(dp_urn)
            for g_urn in group_urns:
                group_name = g_urn.removeprefix(CORP_GROUP_URN_PREFIX)
                group_to_dps.setdefault(group_name, set()).add(dp_urn)

        results: list[GroupOwnershipState] = []
        for group_name in sorted(group_to_dps):
            dp_urns = group_to_dps[group_name]
            all_datasets: set[str] = set()
            for dp_urn in dp_urns:
                datasets = self._datahub.get_datasets_for_data_product(dp_urn)
                all_datasets.update(datasets)
            results.append(
                GroupOwnershipState(
                    group_name=group_name,
                    data_product_urns=sorted(dp_urns),
                    dataset_urns=sorted(all_datasets),
                )
            )

        self._log.info(
            "full resolution complete",
            groups=len(results),
            total_datasets=sum(len(s.dataset_urns) for s in results),
        )
        return results
