"""Orchestrates ownership resolution and downstream sync.

Handles both event-driven updates (single group) and periodic full
reconciliation (all groups).  All operations are idempotent — processing
the same event twice produces the same downstream state.

Exceptions are never silently swallowed.  Every failure is logged with full
context and propagated through :class:`SyncResult.errors`.
"""

from __future__ import annotations

import asyncio
import time

import structlog

from app.config import Settings
from app.models.domain import GroupOwnershipState, SyncResult
from app.models.events import OwnershipChangeEvent
from app.services.configmap_sync import ConfigMapSyncService
from app.services.group_mapper import GroupNameMapper
from app.services.keycloak_sync import KeycloakSyncService
from app.services.opa_policy_builder import OpaPolicyBuilder
from app.services.ownership_resolver import OwnershipResolver

logger = structlog.get_logger(__name__)

CORP_GROUP_URN_PREFIX = "urn:li:corpGroup:"


class Reconciler:
    """Central orchestrator for the resolve -> sync pipeline.

    Args:
        ownership_resolver: Resolves group ownership from DataHub.
        keycloak_sync: Writes allowed_access to Keycloak groups.
        configmap_sync: Writes OPA policy to a Kubernetes ConfigMap.
        policy_builder: Renders OPA policy JSON.
        group_mapper: Translates group names between systems.
        settings: Application settings (dry_run, etc.).
    """

    def __init__(
        self,
        ownership_resolver: OwnershipResolver,
        keycloak_sync: KeycloakSyncService,
        configmap_sync: ConfigMapSyncService,
        policy_builder: OpaPolicyBuilder,
        group_mapper: GroupNameMapper,
        settings: Settings,
    ) -> None:
        self._resolver = ownership_resolver
        self._keycloak = keycloak_sync
        self._configmap = configmap_sync
        self._policy_builder = policy_builder
        self._mapper = group_mapper
        self._settings = settings
        self._log = logger.bind(service="reconciler")

    # ------------------------------------------------------------------
    # Event-driven path
    # ------------------------------------------------------------------

    async def handle_ownership_change(
        self,
        event: OwnershipChangeEvent,
    ) -> list[SyncResult]:
        """Process a single ownership-change event.

        For each affected group in the event:
        1. Recompute the full dataset list from DataHub (source of truth).
        2. Sync to Keycloak.

        After all groups are processed, rebuild and sync the full OPA policy
        to the ConfigMap so it reflects the latest state.

        Args:
            event: Parsed ownership change event.

        Returns:
            One :class:`SyncResult` per affected group.
        """
        t0 = time.monotonic()
        self._log.info(
            "handling ownership change",
            entity_urn=event.entity_urn,
            change_type=event.change_type,
            groups=event.affected_group_urns,
        )
        results: list[SyncResult] = []

        for group_urn in event.affected_group_urns:
            group_name = group_urn.removeprefix(CORP_GROUP_URN_PREFIX)
            self._log.debug("processing affected group", group=group_name)
            result = await asyncio.to_thread(self._sync_single_group, group_name)
            results.append(result)

        opa_error = await self._rebuild_and_sync_opa()
        if opa_error:
            for r in results:
                r.errors.append(opa_error)
        else:
            for r in results:
                r.opa_synced = True

        elapsed = round(time.monotonic() - t0, 2)
        self._log.info(
            "ownership change handled",
            entity_urn=event.entity_urn,
            groups_processed=len(results),
            errors=sum(1 for r in results if r.errors),
            elapsed_seconds=elapsed,
        )
        return results

    # ------------------------------------------------------------------
    # Full reconciliation path
    # ------------------------------------------------------------------

    async def reconcile(self) -> list[SyncResult]:
        """Full reconciliation: resolve all groups and sync everything.

        Intended to run periodically to repair any drift from missed events
        or partial failures.

        Returns:
            One :class:`SyncResult` per group with ownership.
        """
        t0 = time.monotonic()
        self._log.info("starting full reconciliation")
        states = await asyncio.to_thread(self._resolver.resolve_all_groups)
        self._log.debug("resolved all group states", groups=len(states))

        results: list[SyncResult] = []
        for state in states:
            result = self._sync_group_to_keycloak(state)
            results.append(result)

        opa_error = await self._sync_opa_from_states(states)
        if opa_error:
            for r in results:
                r.errors.append(opa_error)
        else:
            for r in results:
                r.opa_synced = True

        elapsed = round(time.monotonic() - t0, 2)
        self._log.info(
            "reconciliation complete",
            groups=len(results),
            errors=sum(1 for r in results if r.errors),
            elapsed_seconds=elapsed,
        )
        return results

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _sync_single_group(self, group_name: str) -> SyncResult:
        """Resolve and sync one group to Keycloak.

        Args:
            group_name: DataHub corp-group name.

        Returns:
            Sync result for the group.
        """
        self._log.debug("resolving single group", group=group_name)
        try:
            state = self._resolver.resolve_group_datasets(group_name)
        except Exception as exc:
            self._log.exception("failed to resolve group datasets", group=group_name)
            return SyncResult(
                group_name=group_name,
                errors=[f"DataHub resolution failed: {exc}"],
            )
        return self._sync_group_to_keycloak(state)

    def _sync_group_to_keycloak(self, state: GroupOwnershipState) -> SyncResult:
        """Push a resolved state to Keycloak.

        Args:
            state: Fully resolved group ownership.

        Returns:
            Sync result.
        """
        result = SyncResult(
            group_name=state.group_name,
            datasets_count=len(state.dataset_urns),
            dry_run=self._settings.dry_run,
        )

        if self._settings.dry_run:
            self._log.info(
                "dry-run: would sync to keycloak",
                group=state.group_name,
                datasets=len(state.dataset_urns),
                dataset_urns=state.dataset_urns,
            )
            return result

        try:
            self._keycloak.sync_group_access(state.group_name, state.dataset_urns)
            result.keycloak_synced = True
            self._log.debug(
                "keycloak sync succeeded",
                group=state.group_name,
                datasets=len(state.dataset_urns),
            )
        except Exception as exc:
            self._log.exception(
                "keycloak sync failed",
                group=state.group_name,
                datasets=len(state.dataset_urns),
            )
            result.errors.append(f"Keycloak sync failed: {exc}")

        return result

    async def _rebuild_and_sync_opa(self) -> str | None:
        """Resolve ALL groups and write the full OPA policy.

        Even when processing a single event we rebuild the complete policy
        so the ConfigMap always reflects the total state.

        Returns:
            Error message if the sync failed, or ``None`` on success.
        """
        try:
            states = await asyncio.to_thread(self._resolver.resolve_all_groups)
        except Exception as exc:
            self._log.exception("failed to resolve all groups for OPA rebuild")
            return f"OPA rebuild failed during resolution: {exc}"
        return await self._sync_opa_from_states(states)

    async def _sync_opa_from_states(
        self,
        states: list[GroupOwnershipState],
    ) -> str | None:
        """Build and write OPA policy from pre-resolved states.

        Args:
            states: Complete list of group ownership states.

        Returns:
            Error message if the sync failed, or ``None`` on success.
        """
        policy_json = self._policy_builder.build_policy(states)
        self._log.debug("built OPA policy", policy_size=len(policy_json), groups=len(states))

        if not self._policy_builder.validate_policy(policy_json):
            msg = "generated policy failed validation, skipping configmap update"
            self._log.error(msg)
            return msg

        if self._settings.dry_run:
            self._log.info("dry-run: would update OPA configmap", policy_size=len(policy_json))
            return None

        try:
            await asyncio.to_thread(self._configmap.sync_policy, policy_json)
            self._log.debug("OPA configmap sync completed")
            return None
        except Exception as exc:
            self._log.exception("failed to sync OPA configmap")
            return f"OPA configmap sync failed: {exc}"
