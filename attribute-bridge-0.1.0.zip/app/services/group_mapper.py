"""Abstraction for mapping DataHub group names to Keycloak group names.

The default :class:`DirectGroupNameMapper` uses identity mapping (same name
on both sides).  :class:`ConfigurableGroupNameMapper` reads explicit overrides
from configuration, falling back to identity for unmapped groups.

Both satisfy the :class:`GroupNameMapper` protocol so callers do not need to
know which strategy is in use.
"""

from __future__ import annotations

from typing import Protocol


class GroupNameMapper(Protocol):
    """Protocol for bidirectional group-name translation."""

    def datahub_to_keycloak(self, datahub_group: str) -> str:
        """Translate a DataHub corp-group name to a Keycloak group name.

        Args:
            datahub_group: Group name as it appears in DataHub.

        Returns:
            Corresponding Keycloak group name.
        """
        ...

    def keycloak_to_datahub(self, keycloak_group: str) -> str:
        """Translate a Keycloak group name back to a DataHub corp-group name.

        Args:
            keycloak_group: Group name as it appears in Keycloak.

        Returns:
            Corresponding DataHub group name.
        """
        ...


class DirectGroupNameMapper:
    """Identity mapper — DataHub and Keycloak use the same group names."""

    def datahub_to_keycloak(self, datahub_group: str) -> str:
        """Return the group name unchanged.

        Args:
            datahub_group: Group name as it appears in DataHub.

        Returns:
            The same string.
        """
        return datahub_group

    def keycloak_to_datahub(self, keycloak_group: str) -> str:
        """Return the group name unchanged.

        Args:
            keycloak_group: Group name as it appears in Keycloak.

        Returns:
            The same string.
        """
        return keycloak_group


class ConfigurableGroupNameMapper:
    """Maps group names using an explicit dictionary, falling back to identity.

    Args:
        mapping: ``{datahub_name: keycloak_name}`` overrides.
    """

    def __init__(self, mapping: dict[str, str]) -> None:
        self._dh_to_kc = dict(mapping)
        self._kc_to_dh = {v: k for k, v in mapping.items()}

    def datahub_to_keycloak(self, datahub_group: str) -> str:
        """Translate using the mapping, falling back to identity.

        Args:
            datahub_group: Group name as it appears in DataHub.

        Returns:
            Mapped Keycloak name, or the original if no override exists.
        """
        return self._dh_to_kc.get(datahub_group, datahub_group)

    def keycloak_to_datahub(self, keycloak_group: str) -> str:
        """Reverse-translate using the mapping, falling back to identity.

        Args:
            keycloak_group: Group name as it appears in Keycloak.

        Returns:
            Mapped DataHub name, or the original if no override exists.
        """
        return self._kc_to_dh.get(keycloak_group, keycloak_group)


def build_group_mapper(
    mode: str,
    mapping: dict[str, str] | None = None,
) -> GroupNameMapper:
    """Factory that returns the appropriate mapper based on configuration.

    Args:
        mode: ``"name"`` for identity mapping, ``"mapping"`` for explicit overrides.
        mapping: Explicit overrides (required when *mode* is ``"mapping"``).

    Returns:
        A :class:`GroupNameMapper` implementation.
    """
    if mode == "mapping" and mapping:
        return ConfigurableGroupNameMapper(mapping)
    return DirectGroupNameMapper()
