"""Kafka consumer for DataHub MetadataChangeLog events.

Listens on the MCL topic, filters for ownership changes on Data Products
where the owner is a corp-group, and dispatches parsed events to a callback.

The consume loop auto-restarts with exponential backoff on crashes to prevent
a transient Kafka error from permanently disabling event processing.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
from collections.abc import Awaitable, Callable

import structlog
from aiokafka import AIOKafkaConsumer

from app.config import Settings
from app.models.events import OwnershipChangeEvent
from app.services.mcl_parser import parse_ownership_change_from_mcl

logger = structlog.get_logger(__name__)

_RESTART_BASE_DELAY = 5.0
_RESTART_MAX_DELAY = 120.0


class KafkaEventListener:
    """Async Kafka consumer that emits :class:`OwnershipChangeEvent` objects.

    The internal consume loop auto-restarts on unexpected errors so that a
    single transient failure does not permanently disable event processing.

    Args:
        settings: Application settings with Kafka connection details.
        callback: Async function invoked for each relevant ownership event.
    """

    def __init__(
        self,
        settings: Settings,
        callback: Callable[[OwnershipChangeEvent], Awaitable[None]],
    ) -> None:
        self._settings = settings
        self._callback = callback
        self._consumer: AIOKafkaConsumer | None = None
        self._task: asyncio.Task[None] | None = None
        self._log = logger.bind(component="kafka_event_listener")

    async def start(self) -> None:
        """Create the Kafka consumer and begin background consumption.

        Raises:
            Exception: If the initial Kafka connection fails.
        """
        self._log.debug(
            "connecting to kafka",
            bootstrap_servers=self._settings.datahub_kafka_bootstrap_servers,
            topic=self._settings.datahub_kafka_topic,
            group=self._settings.datahub_kafka_consumer_group,
        )
        self._consumer = AIOKafkaConsumer(
            self._settings.datahub_kafka_topic,
            bootstrap_servers=self._settings.datahub_kafka_bootstrap_servers,
            group_id=self._settings.datahub_kafka_consumer_group,
            auto_offset_reset="latest",
            enable_auto_commit=True,
            value_deserializer=lambda m: json.loads(m.decode("utf-8")),
        )
        await self._consumer.start()
        self._task = asyncio.create_task(self._consume_with_restart())
        self._log.info(
            "kafka event listener started",
            topic=self._settings.datahub_kafka_topic,
            group=self._settings.datahub_kafka_consumer_group,
        )

    async def stop(self) -> None:
        """Gracefully shut down the consumer and cancel the background task."""
        self._log.debug("stopping kafka event listener")
        if self._task and not self._task.done():
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task
        if self._consumer:
            await self._consumer.stop()
        self._log.info("kafka event listener stopped")

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _consume_with_restart(self) -> None:
        """Wrapper that restarts ``_consume_loop`` on crash with backoff."""
        delay = _RESTART_BASE_DELAY
        while True:
            try:
                await self._consume_loop()
                break
            except asyncio.CancelledError:
                raise
            except Exception:
                self._log.exception(
                    "kafka consume loop crashed, restarting after delay",
                    restart_delay_seconds=delay,
                )
                await asyncio.sleep(delay)
                delay = min(delay * 2, _RESTART_MAX_DELAY)

    async def _consume_loop(self) -> None:
        """Read messages forever, parsing and dispatching relevant events."""
        assert self._consumer is not None
        self._log.debug("entering consume loop")
        async for msg in self._consumer:
            try:
                self._log.debug(
                    "received kafka message",
                    topic=msg.topic,
                    partition=msg.partition,
                    offset=msg.offset,
                )
                event = parse_ownership_change_from_mcl(msg.value)
                if event is not None:
                    self._log.info(
                        "ownership change detected",
                        entity_urn=event.entity_urn,
                        change_type=event.change_type,
                        affected_groups=event.affected_group_urns,
                    )
                    await self._callback(event)
                    self._log.debug(
                        "event callback completed",
                        entity_urn=event.entity_urn,
                    )
                else:
                    self._log.debug(
                        "message filtered out",
                        entity_type=msg.value.get("entityType", "?"),
                        aspect_name=msg.value.get("aspectName", "?"),
                    )
            except asyncio.CancelledError:
                raise
            except Exception:
                raw = msg.value if isinstance(msg.value, dict) else {}
                self._log.exception(
                    "failed to process MCL message",
                    topic=msg.topic,
                    partition=msg.partition,
                    offset=msg.offset,
                    entity_type=raw.get("entityType", "?"),
                    aspect_name=raw.get("aspectName", "?"),
                )
