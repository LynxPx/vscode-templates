"""Synchronises group-to-dataset mappings into Keycloak group attributes.

Writes the ``allowed_access`` multivalued attribute for each group,
fully replacing managed values while preserving unrelated attributes.
"""

from __future__ import annotations

import structlog

from app.clients.keycloak_client import KeycloakClient
from app.services.group_mapper import GroupNameMapper

logger = structlog.get_logger(__name__)


class KeycloakSyncService:
    """Pushes resolved dataset-access lists into Keycloak groups.

    Args:
        keycloak_client: Client for Keycloak Admin REST API.
        group_mapper: Translates DataHub group names to Keycloak group names.
    """

    def __init__(
        self,
        keycloak_client: KeycloakClient,
        group_mapper: GroupNameMapper,
    ) -> None:
        self._keycloak = keycloak_client
        self._mapper = group_mapper
        self._log = logger.bind(service="keycloak_sync")

    def sync_group_access(
        self,
        datahub_group_name: str,
        dataset_urns: list[str],
    ) -> None:
        """Update the ``allowed_access`` attribute for one group in Keycloak.

        The operation is idempotent: calling with the same URN list produces
        no change.  Only the managed attribute is modified.

        Args:
            datahub_group_name: Group name as it appears in DataHub.
            dataset_urns: Fully recomputed, sorted list of dataset URNs.

        Raises:
            ValueError: If the Keycloak group cannot be found.
        """
        kc_group = self._mapper.datahub_to_keycloak(datahub_group_name)
        self._log.info(
            "syncing group to keycloak",
            datahub_group=datahub_group_name,
            keycloak_group=kc_group,
            datasets=len(dataset_urns),
        )
        self._log.debug(
            "dataset URNs for keycloak sync",
            group=kc_group,
            urns=dataset_urns,
        )
        self._keycloak.update_group_allowed_access(kc_group, dataset_urns)
        self._log.debug("keycloak sync completed", group=kc_group)

    def sync_all_groups(
        self,
        group_datasets: dict[str, list[str]],
    ) -> dict[str, str | None]:
        """Sync multiple groups, collecting per-group error messages.

        Args:
            group_datasets: ``{datahub_group_name: [dataset_urn, ...]}``.

        Returns:
            ``{datahub_group_name: error_message | None}``.  ``None`` means success.
        """
        results: dict[str, str | None] = {}
        for group_name, urns in sorted(group_datasets.items()):
            try:
                self.sync_group_access(group_name, urns)
                results[group_name] = None
            except Exception as exc:
                self._log.exception(
                    "keycloak sync failed for group",
                    group=group_name,
                    datasets=len(urns),
                )
                results[group_name] = str(exc)
        return results
