"""Keycloak Admin REST API client for group attribute management.

Uses ``python-keycloak`` to authenticate with a service account and
update the ``allowed_access`` multivalued attribute on groups.
"""

from __future__ import annotations

import logging

import structlog
from keycloak import KeycloakAdmin
from keycloak.exceptions import KeycloakError
from tenacity import (
    before_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from app.config import Settings

logger = structlog.get_logger(__name__)
_stdlib_logger = logging.getLogger(__name__)


class KeycloakClient:
    """Manages Keycloak group attributes for dataset access control.

    Args:
        settings: Application settings with Keycloak connection details.
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._attribute_name = settings.keycloak_group_attribute_name
        self._admin = KeycloakAdmin(
            server_url=settings.keycloak_url,
            realm_name=settings.keycloak_realm,
            client_id=settings.keycloak_client_id,
            client_secret_key=settings.keycloak_client_secret,
        )
        self._log = logger.bind(client="keycloak")
        self._log.debug(
            "keycloak client initialised",
            url=settings.keycloak_url,
            realm=settings.keycloak_realm,
            client_id=settings.keycloak_client_id,
        )

    def verify_connection(self) -> str:
        """Confirm that Keycloak is reachable and the service account can read the realm.

        Returns:
            A short human-readable success message including the realm id.

        Raises:
            KeycloakError: If the admin API returns an error.
            ConnectionError: On network failures.
        """
        realm: dict[str, object] = self._admin.get_realm(self._settings.keycloak_realm)
        realm_id = str(realm.get("id", ""))
        return f"realm '{self._settings.keycloak_realm}' ok (id={realm_id})"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((KeycloakError, ConnectionError, OSError)),
        reraise=True,
        before=before_log(_stdlib_logger, logging.DEBUG),
    )
    def update_group_allowed_access(
        self,
        group_name: str,
        dataset_urns: list[str],
    ) -> None:
        """Set the managed attribute on a Keycloak group, preserving other attributes.

        Args:
            group_name: Keycloak group name to look up.
            dataset_urns: Full list of dataset URNs to set as the attribute value.

        Raises:
            ValueError: If the group cannot be found in Keycloak.
            KeycloakError: If the Keycloak API returns an error.
        """
        self._log.debug("looking up keycloak group", group=group_name)
        group_id = self._resolve_group_id(group_name)
        self._log.debug("fetching full group details", group=group_name, group_id=group_id)

        full_group: dict[str, object] = self._admin.get_group(group_id)

        attributes: dict[str, list[str]] = dict(full_group.get("attributes") or {})  # type: ignore[arg-type]
        previous_values = attributes.get(self._attribute_name, [])
        attributes[self._attribute_name] = dataset_urns

        self._log.debug(
            "updating group attributes",
            group=group_name,
            attribute=self._attribute_name,
            previous_count=len(previous_values),
            new_count=len(dataset_urns),
        )
        self._admin.update_group(group_id, {"attributes": attributes})
        self._log.info(
            "updated keycloak group attributes",
            group=group_name,
            attribute=self._attribute_name,
            values_count=len(dataset_urns),
        )

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((KeycloakError, ConnectionError, OSError)),
        reraise=True,
        before=before_log(_stdlib_logger, logging.DEBUG),
    )
    def get_group_allowed_access(self, group_name: str) -> list[str]:
        """Read the current managed attribute values for a group.

        Args:
            group_name: Keycloak group name.

        Returns:
            Current list of dataset URNs, or empty list if attribute is absent.

        Raises:
            ValueError: If the group cannot be found.
            KeycloakError: If the Keycloak API returns an error.
        """
        group_id = self._resolve_group_id(group_name)
        full_group: dict[str, object] = self._admin.get_group(group_id)
        attributes: dict[str, list[str]] = full_group.get("attributes") or {}  # type: ignore[assignment]
        values = list(attributes.get(self._attribute_name, []))
        self._log.debug(
            "read group allowed_access",
            group=group_name,
            values_count=len(values),
        )
        return values

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_group_id(self, group_name: str) -> str:
        """Find the Keycloak internal group ID for a given name.

        Performs a search with ``exact=True``, then falls back to a broader
        substring search with manual filtering.

        Args:
            group_name: Keycloak group name.

        Returns:
            Internal Keycloak group UUID.

        Raises:
            ValueError: When no matching group is found.
        """
        self._log.debug("resolving keycloak group id", group=group_name)

        candidates: list[dict[str, object]] = self._admin.get_groups(
            query={"search": group_name, "exact": True}
        )
        self._log.debug(
            "exact search results",
            group=group_name,
            candidates_count=len(candidates),
        )
        for group in candidates:
            if group.get("name") == group_name:
                group_id = str(group["id"])
                self._log.debug("group resolved via exact search", group=group_name, id=group_id)
                return group_id

        broader: list[dict[str, object]] = self._admin.get_groups(query={"search": group_name})
        self._log.debug(
            "broad search results",
            group=group_name,
            candidates_count=len(broader),
        )
        for group in broader:
            if group.get("name") == group_name:
                group_id = str(group["id"])
                self._log.debug("group resolved via broad search", group=group_name, id=group_id)
                return group_id

        self._log.error("keycloak group not found", group=group_name)
        raise ValueError(f"Keycloak group not found: {group_name}")
