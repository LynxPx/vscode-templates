"""DataHub client for ownership and data-product queries.

Uses the official ``acryl-datahub`` SDK for:
- GraphQL ``search`` queries (owner-filtered, listing)
- REST-based aspect fetching for ``DataProductProperties`` and ``Ownership``

This hybrid approach maximises reliability across DataHub server versions.
GraphQL calls use ``strip_unsupported_fields=True`` for forward compatibility.
"""

from __future__ import annotations

import logging

import structlog
from datahub.ingestion.graph.client import DatahubClientConfig, DataHubGraph
from datahub.metadata.schema_classes import DataProductPropertiesClass, OwnershipClass
from tenacity import (
    before_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from app.config import Settings

logger = structlog.get_logger(__name__)
_stdlib_logger = logging.getLogger(__name__)

CORP_GROUP_URN_PREFIX = "urn:li:corpGroup:"
DATASET_URN_PREFIX = "urn:li:dataset:"

# ---------------------------------------------------------------------------
# GraphQL queries — used only where the SDK lacks a convenience method
# ---------------------------------------------------------------------------

_SEARCH_DATA_PRODUCTS_BY_OWNER = """
query searchDataProductsByOwner($groupUrn: String!, $start: Int!, $count: Int!) {
  search(input: {
    type: DATA_PRODUCT
    query: "*"
    orFilters: [{
      and: [{
        field: "owners"
        values: [$groupUrn]
      }]
    }]
    start: $start
    count: $count
  }) {
    start
    count
    total
    searchResults {
      entity {
        urn
        type
      }
    }
  }
}
"""

_LIST_ALL_DATA_PRODUCTS = """
query listAllDataProducts($start: Int!, $count: Int!) {
  search(input: {
    type: DATA_PRODUCT
    query: "*"
    start: $start
    count: $count
  }) {
    start
    count
    total
    searchResults {
      entity {
        urn
        type
      }
    }
  }
}
"""

_DEFAULT_PAGE_SIZE = 200


class DataHubClient:
    """Client for querying DataHub ownership and data-product membership.

    Uses GraphQL ``search`` for filtered/listing queries and the SDK's
    REST-based aspect methods for ``Ownership`` and ``DataProductProperties``.

    Args:
        settings: Application settings containing DataHub connection details.
    """

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._graph = DataHubGraph(
            DatahubClientConfig(
                server=settings.datahub_url,
                token=settings.datahub_token or None,
            )
        )
        self._log = logger.bind(client="datahub")
        self._log.debug(
            "datahub client initialised",
            server=settings.datahub_url,
            has_token=bool(settings.datahub_token),
        )

    def verify_connection(self) -> str:
        """Confirm that DataHub GMS is reachable and credentials work.

        Calls the SDK ``test_connection`` path (fetches server configuration).

        Returns:
            A short human-readable success message.

        Raises:
            Exception: On network errors, HTTP failures, or auth rejection from GMS.
        """
        self._graph.test_connection()
        return "GMS reachable (server config fetched)"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((ConnectionError, OSError, TimeoutError)),
        reraise=True,
        before=before_log(_stdlib_logger, logging.DEBUG),
    )
    def get_data_products_for_group(self, group_urn: str) -> list[str]:
        """Return all Data Product URNs where *group_urn* is an owner.

        Uses the GraphQL ``search`` API with an ``owners`` filter.

        Args:
            group_urn: Full corp-group URN, e.g. ``urn:li:corpGroup:analytics``.

        Returns:
            Sorted list of Data Product URN strings.
        """
        self._log.debug("searching data products for group", group_urn=group_urn)
        results = self._paginated_search(
            _SEARCH_DATA_PRODUCTS_BY_OWNER,
            {"groupUrn": group_urn},
        )
        urns = sorted({r["entity"]["urn"] for r in results})
        self._log.info(
            "resolved data products for group",
            group_urn=group_urn,
            count=len(urns),
        )
        self._log.debug("data product URNs for group", group_urn=group_urn, urns=urns)
        return urns

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((ConnectionError, OSError, TimeoutError)),
        reraise=True,
        before=before_log(_stdlib_logger, logging.DEBUG),
    )
    def get_datasets_for_data_product(self, data_product_urn: str) -> list[str]:
        """Return dataset URNs that belong to a Data Product.

        Fetches the ``DataProductProperties`` aspect via the REST API and
        extracts ``assets[*].destinationUrn`` where the URN is a dataset.

        Args:
            data_product_urn: URN of the Data Product.

        Returns:
            Sorted list of dataset URN strings.
        """
        self._log.debug("resolving datasets for data product", dp_urn=data_product_urn)

        props: DataProductPropertiesClass | None = self._graph.get_aspect(
            entity_urn=data_product_urn,
            aspect_type=DataProductPropertiesClass,
        )

        if props is None or props.assets is None:
            self._log.warning(
                "no DataProductProperties or assets found",
                dp_urn=data_product_urn,
            )
            return []

        datasets = sorted(
            {
                asset.destinationUrn
                for asset in props.assets
                if asset.destinationUrn.startswith(DATASET_URN_PREFIX)
            }
        )
        self._log.info(
            "resolved datasets for data product",
            dp_urn=data_product_urn,
            total_assets=len(props.assets),
            dataset_count=len(datasets),
        )
        self._log.debug("dataset URNs", dp_urn=data_product_urn, urns=datasets)
        return datasets

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((ConnectionError, OSError, TimeoutError)),
        reraise=True,
        before=before_log(_stdlib_logger, logging.DEBUG),
    )
    def get_data_product_group_owners(self, data_product_urn: str) -> list[str]:
        """Return corp-group owner URNs for a Data Product.

        Uses the SDK's ``get_ownership()`` REST method for reliability.

        Args:
            data_product_urn: URN of the Data Product.

        Returns:
            Sorted list of corp-group URN strings.
        """
        self._log.debug("fetching ownership for data product", dp_urn=data_product_urn)

        ownership: OwnershipClass | None = self._graph.get_ownership(data_product_urn)

        if ownership is None or ownership.owners is None:
            self._log.debug("no ownership aspect found", dp_urn=data_product_urn)
            return []

        group_urns = sorted(
            {
                str(owner.owner)
                for owner in ownership.owners
                if str(owner.owner).startswith(CORP_GROUP_URN_PREFIX)
            }
        )
        self._log.debug(
            "resolved group owners",
            dp_urn=data_product_urn,
            total_owners=len(ownership.owners),
            group_owners=group_urns,
        )
        return group_urns

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((ConnectionError, OSError, TimeoutError)),
        reraise=True,
        before=before_log(_stdlib_logger, logging.DEBUG),
    )
    def list_all_data_products(self) -> list[str]:
        """Return URNs of every Data Product in the catalog.

        Uses the GraphQL ``search`` API with a wildcard query.

        Returns:
            Sorted list of Data Product URN strings.
        """
        self._log.debug("listing all data products")
        results = self._paginated_search(_LIST_ALL_DATA_PRODUCTS, {})
        urns = sorted({r["entity"]["urn"] for r in results})
        self._log.info("listed all data products", count=len(urns))
        return urns

    # ------------------------------------------------------------------
    # Pagination helper
    # ------------------------------------------------------------------

    def _paginated_search(
        self,
        query: str,
        variables: dict[str, object],
        page_size: int = _DEFAULT_PAGE_SIZE,
    ) -> list[dict[str, object]]:
        """Execute a paginated GraphQL search query.

        Args:
            query: GraphQL query with ``$start`` / ``$count`` variables.
            variables: Additional query variables.
            page_size: Number of results per page.

        Returns:
            Aggregated ``searchResults`` list across all pages.

        Raises:
            Exception: If the GraphQL query returns errors.
        """
        collected: list[dict[str, object]] = []
        start = 0
        while True:
            page_vars = {**variables, "start": start, "count": page_size}
            self._log.debug(
                "executing paginated search",
                start=start,
                count=page_size,
            )
            response = self._graph.execute_graphql(
                query,
                page_vars,
                strip_unsupported_fields=True,
            )
            search_data = response.get("search", {})
            results = search_data.get("searchResults", [])
            collected.extend(results)
            total = search_data.get("total", 0)
            self._log.debug(
                "search page received",
                start=start,
                page_results=len(results),
                total=total,
            )
            if start + page_size >= total:
                break
            start += page_size
        return collected
