"""Kubernetes client for reading and updating OPA policy ConfigMaps.

Supports both in-cluster (service account) and out-of-cluster (kubeconfig)
authentication via the official ``kubernetes`` Python client.
"""

from __future__ import annotations

import logging

import structlog
from kubernetes import client as k8s_client
from kubernetes import config as k8s_config
from kubernetes.client.exceptions import ApiException
from kubernetes.config.config_exception import ConfigException
from tenacity import (
    before_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)
from urllib3.exceptions import HTTPError as Urllib3HTTPError

from app.config import Settings

logger = structlog.get_logger(__name__)
_stdlib_logger = logging.getLogger(__name__)


class K8sClient:
    """Manages a single Kubernetes ConfigMap used to deliver OPA policy data to Trino.

    When ``k8s_in_cluster`` is enabled, in-cluster credentials are loaded first; if the
    process is not running inside a pod (e.g. local dev with ``K8S_IN_CLUSTER=true``),
    loading falls back to kubeconfig after a warning.

    Args:
        settings: Application settings with K8s connection details.
    """

    def __init__(self, settings: Settings) -> None:
        self._namespace = settings.k8s_namespace
        self._configmap_name = settings.k8s_configmap_name
        self._configmap_key = settings.k8s_configmap_key
        self._log = logger.bind(client="k8s")

        if settings.k8s_in_cluster:
            self._log.debug("loading in-cluster kubernetes config")
            try:
                k8s_config.load_incluster_config()
            except ConfigException as exc:
                self._log.warning(
                    "in-cluster kubernetes config unavailable, falling back to kubeconfig",
                    reason=str(exc),
                )
                k8s_config.load_kube_config()
        else:
            self._log.debug("loading kubeconfig from default location")
            k8s_config.load_kube_config()

        self._v1 = k8s_client.CoreV1Api()
        self._log.debug(
            "k8s client initialised",
            namespace=self._namespace,
            configmap=self._configmap_name,
            key=self._configmap_key,
        )

    def verify_connection(self) -> str:
        """Confirm that the Kubernetes API server is reachable with current credentials.

        Uses the version discovery endpoint (``/version``), which does not require
        access to the managed ConfigMap.

        Returns:
            A short human-readable success message including the server git version.

        Raises:
            ApiException: On HTTP errors from the API server.
            ConfigException: If client configuration is invalid (unlikely after ``__init__``).
        """
        version_api = k8s_client.VersionApi()
        code = version_api.get_code()
        git_version = getattr(code, "git_version", None) or "unknown"
        return f"Kubernetes API ok ({git_version})"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((ApiException, ConnectionError, OSError, Urllib3HTTPError)),
        reraise=True,
        before=before_log(_stdlib_logger, logging.DEBUG),
    )
    def read_configmap_data(self) -> dict[str, str]:
        """Read the current data from the managed ConfigMap.

        Returns:
            Dictionary of key -> value from the ConfigMap ``data`` field.
            Empty dict if the ConfigMap does not exist.

        Raises:
            ApiException: On non-404 Kubernetes API errors (after retries).
        """
        self._log.debug(
            "reading configmap",
            name=self._configmap_name,
            namespace=self._namespace,
        )
        try:
            cm = self._v1.read_namespaced_config_map(self._configmap_name, self._namespace)
            data = dict(cm.data or {})
            self._log.debug(
                "configmap read successfully",
                name=self._configmap_name,
                keys=list(data.keys()),
            )
            return data
        except ApiException as exc:
            if exc.status == 404:
                self._log.warning(
                    "configmap not found, will create on first write",
                    name=self._configmap_name,
                    namespace=self._namespace,
                )
                return {}
            self._log.error(
                "failed to read configmap",
                name=self._configmap_name,
                namespace=self._namespace,
                status=exc.status,
                reason=exc.reason,
            )
            raise

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((ApiException, ConnectionError, OSError, Urllib3HTTPError)),
        reraise=True,
        before=before_log(_stdlib_logger, logging.DEBUG),
    )
    def write_policy_data(self, policy_json: str) -> None:
        """Create or update the policy key in the managed ConfigMap.

        If the ConfigMap does not exist it is created. Only the configured
        policy key is written; other keys in the ConfigMap are preserved via
        a strategic-merge patch.

        Args:
            policy_json: Serialised JSON string to store.

        Raises:
            ApiException: On non-404 Kubernetes API errors (after retries).
        """
        data = {self._configmap_key: policy_json}
        self._log.debug(
            "writing policy to configmap",
            name=self._configmap_name,
            namespace=self._namespace,
            key=self._configmap_key,
            policy_size=len(policy_json),
        )

        try:
            self._v1.read_namespaced_config_map(self._configmap_name, self._namespace)
            body = k8s_client.V1ConfigMap(data=data)
            self._v1.patch_namespaced_config_map(self._configmap_name, self._namespace, body)
            self._log.info(
                "patched configmap",
                name=self._configmap_name,
                key=self._configmap_key,
            )
        except ApiException as exc:
            if exc.status == 404:
                self._log.info(
                    "configmap does not exist, creating",
                    name=self._configmap_name,
                    namespace=self._namespace,
                )
                body = k8s_client.V1ConfigMap(
                    metadata=k8s_client.V1ObjectMeta(
                        name=self._configmap_name,
                        namespace=self._namespace,
                    ),
                    data=data,
                )
                self._v1.create_namespaced_config_map(self._namespace, body)
                self._log.info(
                    "created configmap",
                    name=self._configmap_name,
                    key=self._configmap_key,
                )
            else:
                self._log.error(
                    "failed to write configmap",
                    name=self._configmap_name,
                    namespace=self._namespace,
                    status=exc.status,
                    reason=exc.reason,
                )
                raise

    def read_policy_key(self) -> str | None:
        """Read only the managed policy key from the ConfigMap.

        Returns:
            The policy JSON string, or ``None`` if the key is absent.
        """
        data = self.read_configmap_data()
        value = data.get(self._configmap_key)
        self._log.debug(
            "read policy key",
            key=self._configmap_key,
            found=value is not None,
        )
        return value
