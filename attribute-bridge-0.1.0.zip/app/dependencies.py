"""FastAPI dependency-injection wiring.

Constructs and caches service instances so that route handlers and
background tasks share the same objects.  Each ``get_*`` accessor is
memoised with :func:`functools.lru_cache`; the first call (including from
:func:`app.main.lifespan` via ``get_reconciler()``) constructs
:class:`~app.clients.k8s_client.K8sClient` and loads kubeconfig / in-cluster
config, so a missing or invalid Kubernetes configuration fails at that moment
—not on the first HTTP request.
"""

from __future__ import annotations

from functools import lru_cache

from app.clients.datahub_client import DataHubClient
from app.clients.k8s_client import K8sClient
from app.clients.keycloak_client import KeycloakClient
from app.config import Settings
from app.services.configmap_sync import ConfigMapSyncService
from app.services.group_mapper import GroupNameMapper, build_group_mapper
from app.services.keycloak_sync import KeycloakSyncService
from app.services.opa_policy_builder import OpaPolicyBuilder
from app.services.ownership_resolver import OwnershipResolver
from app.services.reconciler import Reconciler


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the singleton application settings instance.

    Returns:
        Parsed :class:`Settings` from environment / .env file.
    """
    return Settings()  # type: ignore[call-arg]


@lru_cache(maxsize=1)
def get_datahub_client() -> DataHubClient:
    """Return the singleton DataHub client.

    Returns:
        Configured :class:`DataHubClient`.
    """
    return DataHubClient(get_settings())


@lru_cache(maxsize=1)
def get_keycloak_client() -> KeycloakClient:
    """Return the singleton Keycloak client.

    Returns:
        Configured :class:`KeycloakClient`.
    """
    return KeycloakClient(get_settings())


@lru_cache(maxsize=1)
def get_k8s_client() -> K8sClient:
    """Return the singleton Kubernetes client.

    Returns:
        Configured :class:`K8sClient`.
    """
    return K8sClient(get_settings())


@lru_cache(maxsize=1)
def get_group_mapper() -> GroupNameMapper:
    """Return the singleton group-name mapper.

    Returns:
        Configured :class:`GroupNameMapper` implementation.
    """
    settings = get_settings()
    return build_group_mapper(
        mode=settings.keycloak_group_match_mode,
        mapping=settings.group_name_mapping or None,
    )


@lru_cache(maxsize=1)
def get_ownership_resolver() -> OwnershipResolver:
    """Return the singleton ownership resolver.

    Returns:
        Configured :class:`OwnershipResolver`.
    """
    return OwnershipResolver(get_datahub_client())


def get_policy_builder() -> OpaPolicyBuilder:
    """Return an OPA policy builder instance.

    Returns:
        :class:`OpaPolicyBuilder` (stateless, no caching needed).
    """
    return OpaPolicyBuilder()


@lru_cache(maxsize=1)
def get_keycloak_sync() -> KeycloakSyncService:
    """Return the singleton Keycloak sync service.

    Returns:
        Configured :class:`KeycloakSyncService`.
    """
    return KeycloakSyncService(get_keycloak_client(), get_group_mapper())


@lru_cache(maxsize=1)
def get_configmap_sync() -> ConfigMapSyncService:
    """Return the singleton ConfigMap sync service.

    Returns:
        Configured :class:`ConfigMapSyncService`.
    """
    return ConfigMapSyncService(get_k8s_client(), get_policy_builder())


@lru_cache(maxsize=1)
def get_reconciler() -> Reconciler:
    """Return the singleton reconciler (central orchestrator).

    Returns:
        Configured :class:`Reconciler`.
    """
    return Reconciler(
        ownership_resolver=get_ownership_resolver(),
        keycloak_sync=get_keycloak_sync(),
        configmap_sync=get_configmap_sync(),
        policy_builder=get_policy_builder(),
        group_mapper=get_group_mapper(),
        settings=get_settings(),
    )
