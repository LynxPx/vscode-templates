"""FastAPI route definitions for health, readiness, and admin endpoints."""
