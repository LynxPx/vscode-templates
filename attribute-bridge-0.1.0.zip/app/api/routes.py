"""FastAPI routes for health checks, readiness probes, and admin operations."""

from __future__ import annotations

import time
from typing import Any

import structlog
from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse

from app.config import Settings
from app.dependencies import get_reconciler, get_settings
from app.services.reconciler import Reconciler

logger = structlog.get_logger(__name__)

router = APIRouter()

_start_time = time.monotonic()


# ------------------------------------------------------------------
# Health & readiness
# ------------------------------------------------------------------


@router.get("/health", tags=["probes"])
async def health() -> dict[str, str]:
    """Liveness probe — always returns OK if the process is running.

    Returns:
        ``{"status": "ok"}``
    """
    return {"status": "ok"}


@router.get("/ready", tags=["probes"], response_model=None)
async def readiness(request: Request) -> dict[str, str] | JSONResponse:
    """Readiness probe for orchestrators (e.g. Kubernetes).

    When ``readiness_strict`` is False (default for local dev), always returns OK after
    the app has finished startup. When True, returns 503 if dependency probes failed or
    a required Kafka/actions pipeline failed to start (see lifespan in ``app.main``).

    Args:
        request: Incoming request (used to read startup state on ``request.app.state``).

    Returns:
        ``{"status": "ready"}`` or HTTP 503 with ``{"status": "not_ready"}``.
    """
    if not get_settings().readiness_strict:
        return {"status": "ready"}
    if getattr(request.app.state, "ready_for_traffic", False):
        return {"status": "ready"}
    return JSONResponse(
        status_code=503,
        content={"status": "not_ready"},
    )


@router.get("/metrics", tags=["observability"])
async def metrics() -> dict[str, Any]:
    """Basic operational metrics.

    Returns:
        Uptime and version information.
    """
    return {
        "uptime_seconds": round(time.monotonic() - _start_time, 1),
        "version": "0.1.0",
    }


# ------------------------------------------------------------------
# Admin endpoints
# ------------------------------------------------------------------


@router.post("/admin/reconcile", tags=["admin"])
async def trigger_reconciliation(
    reconciler: Reconciler = Depends(get_reconciler),
) -> dict[str, Any]:
    """Trigger an immediate full reconciliation.

    Resolves all group ownership from DataHub and syncs to Keycloak and OPA.

    Returns:
        Summary of sync results per group.
    """
    logger.info("admin-triggered reconciliation")
    results = await reconciler.reconcile()
    return {
        "groups_processed": len(results),
        "results": [r.model_dump() for r in results],
    }


@router.post("/admin/dry-run", tags=["admin"])
async def trigger_dry_run(
    reconciler: Reconciler = Depends(get_reconciler),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """Perform a dry-run reconciliation (no writes to downstream systems).

    Temporarily forces dry_run mode regardless of the configured setting.

    Returns:
        What *would* be synced.
    """
    original = settings.dry_run
    settings.dry_run = True
    try:
        logger.info("admin-triggered dry-run reconciliation")
        results = await reconciler.reconcile()
    finally:
        settings.dry_run = original
    return {
        "dry_run": True,
        "groups_processed": len(results),
        "results": [r.model_dump() for r in results],
    }
