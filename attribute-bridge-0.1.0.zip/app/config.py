"""Application configuration via pydantic-settings.

All settings are loaded from environment variables (or a .env file).
See .env.example for the full list with descriptions.
"""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Central configuration for AttributeBridge.

    Attributes are grouped by the external system they configure.
    Defaults are safe for local development; override via env vars in production.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- DataHub ---
    datahub_url: str = Field(
        default="http://localhost:8080",
        description="DataHub GMS base URL",
    )
    datahub_token: str = Field(
        default="",
        description="DataHub personal access token (empty for no auth)",
    )
    datahub_kafka_bootstrap_servers: str = Field(
        default="localhost:9092",
        description="Kafka bootstrap servers for MCL consumption",
    )
    datahub_kafka_topic: str = Field(
        default="MetadataChangeLog_Versioned_v1",
        description="Kafka topic for DataHub MetadataChangeLog events",
    )
    datahub_kafka_consumer_group: str = Field(
        default="attribute-bridge",
        description="Kafka consumer group ID",
    )
    datahub_event_source: str = Field(
        default="kafka",
        description=(
            "Event source: 'kafka' (aiokafka+JSON), 'actions' (embedded DataHub Actions + "
            "Confluent/Avro; install [actions] extra), 'polling' (reconciliation-only)"
        ),
    )
    datahub_schema_registry_url: str = Field(
        default="",
        description=(
            "Kafka Schema Registry URL for DATAHUB_EVENT_SOURCE=actions (often "
            "http://gms:8080/schema-registry/api/). Empty = use DataHub SDK defaults / env"
        ),
    )
    datahub_polling_interval_seconds: int = Field(
        default=30,
        description="Polling interval when event source is 'polling'",
    )

    # --- Keycloak ---
    keycloak_url: str = Field(
        default="http://localhost:8180",
        description="Keycloak base URL",
    )
    keycloak_realm: str = Field(
        default="master",
        description="Keycloak realm name",
    )
    keycloak_client_id: str = Field(
        default="attribute-bridge",
        description="Service account client ID in Keycloak",
    )
    keycloak_client_secret: str = Field(
        default="changeme",
        description="Service account client secret in Keycloak",
    )
    keycloak_group_attribute_name: str = Field(
        default="allowed_access",
        description="Keycloak group attribute key managed by this service",
    )
    keycloak_group_match_mode: str = Field(
        default="name",
        description="'name' for direct mapping, 'mapping' to use group_name_mapping",
    )

    # --- Kubernetes / OPA ---
    k8s_namespace: str = Field(
        default="trino",
        description="Kubernetes namespace for the OPA policy ConfigMap",
    )
    k8s_configmap_name: str = Field(
        default="opa-trino-policy",
        description="Name of the ConfigMap storing OPA policy data",
    )
    k8s_configmap_key: str = Field(
        default="policy_data.json",
        description="Key inside the ConfigMap that holds the policy JSON",
    )
    k8s_in_cluster: bool = Field(
        default=False,
        description=(
            "True to use the pod service account (in-cluster config). False uses "
            "kubeconfig (~/.kube/config or KUBECONFIG) for local development"
        ),
    )

    # --- Reconciliation ---
    reconcile_interval_seconds: int = Field(
        default=300,
        description="Seconds between full reconciliation runs",
    )
    reconcile_enabled: bool = Field(
        default=False,
        description=(
            "When True, start the background loop that runs full reconciliation every "
            "reconcile_interval_seconds. When False, rely on events (or polling source) "
            "and optional manual /admin/reconcile"
        ),
    )

    # --- General ---
    log_level: str = Field(
        default="DEBUG",
        description="Logging level (DEBUG, INFO, WARNING, ERROR)",
    )
    dry_run: bool = Field(
        default=False,
        description="When True, compute state but skip writes to Keycloak and K8s",
    )
    readiness_strict: bool = Field(
        default=False,
        description=(
            "When True, GET /ready returns 503 if dependency probes failed or a required "
            "real-time pipeline (kafka/actions) failed to start. Use True in Kubernetes "
            "so traffic and probes reflect real operability."
        ),
    )

    # --- Group Name Mapping ---
    group_name_mapping: dict[str, str] = Field(
        default_factory=dict,
        description="Explicit DataHub->Keycloak group name overrides (JSON string in env)",
    )
