#!/usr/bin/env python3
"""Build ``dist/attribute-bridge-<version>.zip`` with full source, excluding local junk.

Skips virtualenvs, caches, VCS metadata, editor folders, typical secrets (``.env``),
and any pre-existing release zip under ``dist/``. Run from the repository root:

    python3 scripts/package_zip.py
"""

from __future__ import annotations

import sys
import tomllib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"

SKIP_DIR_NAMES = frozenset(
    {
        ".git",
        ".venv",
        "venv",
        "env",
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        "htmlcov",
        ".cursor",
        "node_modules",
        ".idea",
        ".vscode",
        "dist",  # output dir — nothing inside dist goes into the archive
        "build",
        ".eggs",
    }
)

SKIP_FILE_NAMES = frozenset({".coverage", ".DS_Store", "coverage.xml"})

SKIP_SUFFIXES = frozenset({".pyc", ".pyo"})


def _should_skip(path: Path) -> bool:
    """Return True if *path* must not be included in the archive.

    Args:
        path: A file path under :const:`ROOT`.

    Returns:
        Whether to skip this file.
    """
    try:
        rel = path.relative_to(ROOT)
    except ValueError:
        return True
    for part in rel.parts:
        if part in SKIP_DIR_NAMES:
            return True
        if part.endswith(".egg-info"):
            return True
    name = path.name
    if name in SKIP_FILE_NAMES or name == ".env":
        return True
    return path.suffix in SKIP_SUFFIXES


def main() -> int:
    """Create the zip under ``dist/`` and print its path.

    Returns:
        Exit code (0 on success).
    """
    data = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    version = str(data["project"]["version"])
    DIST.mkdir(parents=True, exist_ok=True)
    out = DIST / f"attribute-bridge-{version}.zip"
    if out.exists():
        out.unlink()

    added = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(ROOT.rglob("*")):
            if not path.is_file():
                continue
            if _should_skip(path):
                continue
            arcname = path.relative_to(ROOT)
            zf.write(path, arcname)
            added += 1

    print(f"Wrote {out} ({added} files)", file=sys.stderr)
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
