# attribute-bridge Helm chart

Installs the AttributeBridge microservice (DataHub → Keycloak → OPA ConfigMap sync).

## Prerequisites

- Kubernetes 1.24+
- Helm 3.x
- A `ServiceAccount` in the release namespace (created by default) and RBAC in the namespace where the OPA ConfigMap lives (`opa.configMap.namespace`, default `trino`)
- A Kubernetes **Secret** in the release namespace with at least `DATAHUB_TOKEN` and `KEYCLOAK_CLIENT_SECRET` (unless you temporarily set `secret.create: true` for bootstrap)

## Install

### Production-style (recommended)

1. Create credentials (replace namespace/name as needed):

```bash
kubectl create secret generic attribute-bridge-secrets \
  --namespace attribute-bridge \
  --from-literal=DATAHUB_TOKEN='...' \
  --from-literal=KEYCLOAK_CLIENT_SECRET='...'
```

2. Install the chart (`secret.create` stays `false`; the Secret name defaults to `<release>-secrets` — use `secret.name` if yours differs):

```bash
helm install attribute-bridge ./charts/attribute-bridge \
  --namespace attribute-bridge \
  --create-namespace \
  --set image.repository=your-registry/attribute-bridge \
  --set image.tag=0.1.0
```

### Bootstrap from Helm values (non-production)

```bash
helm install attribute-bridge ./charts/attribute-bridge \
  --namespace attribute-bridge \
  --create-namespace \
  --set secret.create=true \
  --set-file secret.stringData.DATAHUB_TOKEN=/path/to/token.txt \
  --set secret.stringData.KEYCLOAK_CLIENT_SECRET=your-secret \
  --set image.repository=your-registry/attribute-bridge \
  --set image.tag=0.1.0
```

Or use `-f my-values.yaml`.

## Production checklist

- **`replicaCount`**: keep `1` unless you redesign single-writer semantics for the OPA ConfigMap.
- **`secret.create`**: `false`; manage secrets with External Secrets / Sealed Secrets / Vault.
- **`config.LOG_LEVEL`**: `INFO` (default in chart `values.yaml`).
- **`config.READINESS_STRICT`**: `true` (default) so `/ready` is 503 when dependency probes fail or Kafka/actions failed to start.
- **Image**: pin `image.tag` to a digest or semver, not `latest`.
- **Network**: ensure the pod can reach DataHub GMS, Kafka (if used), Keycloak, and the Kubernetes API.
- **RBAC**: confirm `opa.configMap.namespace` / `opa.configMap.name` match the real OPA ConfigMap.

## Secrets

| Mode | Configuration |
|------|----------------|
| External | `secret.create: false`, `secret.name: <existing-secret>` |
| Helm-managed | `secret.create: true` and populate `secret.stringData` |

## Values highlights

| Key | Purpose |
|-----|---------|
| `opa.configMap.namespace` | Namespace of the OPA policy ConfigMap (Role is created here) |
| `opa.configMap.name` | ConfigMap name (must match `K8S_CONFIGMAP_*` the app uses) |
| `config` | Non-sensitive environment variables |
| `deploymentStrategy.type` | `Recreate` (default) avoids concurrent ConfigMap writers |
| `podSecurityContext` / `containerSecurityContext` | Align with image user `10001` |
| `startupProbe` | Allows slow dependency / Kafka startup before liveness kills the pod |

## Validate locally

```bash
helm lint ./charts/attribute-bridge
helm template attribute-bridge ./charts/attribute-bridge \
  -n attribute-bridge \
  -f charts/attribute-bridge/ci/default-values.yaml
```
