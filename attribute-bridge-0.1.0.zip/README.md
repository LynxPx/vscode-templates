# AttributeBridge

A Python microservice that keeps **DataHub ownership**, **Keycloak group attributes**, and **Trino OPA rules** in sync.

DataHub is the source of truth. When a user group is added to or removed from a Data Product's ownership in DataHub, AttributeBridge:

1. Recomputes the full set of datasets the group can access (through all its Data Products).
2. Writes that list as the `allowed_access` attribute on the matching Keycloak group.
3. Generates a deterministic OPA policy JSON document and stores it in a Kubernetes ConfigMap for Trino.

---

## Architecture

```text
┌──────────────┐   MCL Kafka    ┌────────────────────┐
│   DataHub    │ ─────────────▶ │  AttributeBridge   │
│   (source    │                │                    │
│   of truth)  │ ◀── GraphQL ── │  Event Listener    │
└──────────────┘                │  Ownership Resolver│
                                │  Reconciler        │
                                │       │            │
                                │       ├──▶ Keycloak Sync ──▶ Keycloak
                                │       │                      (group attrs)
                                │       └──▶ OPA Policy ──▶ K8s ConfigMap
                                │            Builder          (Trino/OPA)
                                │                    │
                                │  FastAPI (health,  │
                                │   admin endpoints) │
                                └────────────────────┘
```

### Embedded DataHub Actions (no separate YAML or CLI)

We can run the official Actions **Kafka pipeline inside this process** without `datahub-actions` CLI or YAML files on disk:

1. Install optional dependencies: `pip install 'attribute-bridge[actions]'`.
2. Set `DATAHUB_EVENT_SOURCE=actions`.
3. The microservice builds the same structure as an Actions pipeline config in Python (`Pipeline.create({...})`), see `app/services/datahub_actions_pipeline.py`.

**Behavior Approaches**
1. Listening: `kafka` and `actions`
2. On-demand: `polling`

| Mode | Transport | Notes |
|---|---|---|
| `kafka` | `aiokafka`, JSON `json.loads` | Easiest for local/dev; production MCL is often **Avro + Schema Registry**, so this may not work against a real cluster. |
| `actions` | Confluent consumer + Avro | Matches how DataHub ships MCL; requires Schema Registry (typically the URL behind GMS). |
| `polling` | None | Reconciliation loop only. |

### Key design decisions

| Decision | Rationale |
|---|---|
| **Full recomputation on every event** | Never rely on deltas alone, always re-derive from DataHub to guarantee correctness. |
| **Single-replica Deployment with Recreate strategy** | Prevents concurrent ConfigMap writes and duplicate Kafka consumption. |
| **Deterministic JSON output** | Sorted keys and values so identical state always produces identical bytes (diffable, cache-friendly). |
| **Protocol-based GroupNameMapper** | DataHub→Keycloak group-name mapping is behind an interface, making it trivial to swap strategies. |
| **Periodic reconciliation loop** | Repairs any drift from missed events, transient failures, or manual changes. |

---

## Project structure

```
AttributeBridge/
├── app/
│   ├── main.py                     # FastAPI app, lifespan, startup
│   ├── config.py                   # pydantic-settings configuration
│   ├── log_config.py               # Structured logging (structlog)
│   ├── dependencies.py             # FastAPI dependency injection
│   ├── models/
│   │   ├── domain.py               # GroupOwnershipState, DatasetAccessMapping, SyncResult
│   │   └── events.py               # OwnershipChangeEvent, ChangeType
│   ├── clients/
│   │   ├── datahub_client.py       # DataHub GraphQL (acryl-datahub SDK)
│   │   ├── keycloak_client.py      # Keycloak Admin REST (python-keycloak)
│   │   └── k8s_client.py           # Kubernetes ConfigMap (kubernetes client)
│   ├── services/
│   │   ├── event_listener.py       # Kafka MCL consumer (aiokafka)
│   │   ├── ownership_resolver.py   # group → datasets resolution
│   │   ├── keycloak_sync.py        # Write allowed_access to Keycloak
│   │   ├── opa_policy_builder.py   # Build OPA policy JSON
│   │   ├── configmap_sync.py       # Write policy to K8s ConfigMap
│   │   ├── group_mapper.py         # DataHub↔Keycloak name mapping
│   │   └── reconciler.py           # Orchestrates resolve + sync
│   └── api/
│       └── routes.py               # /health, /ready, /metrics, /admin/*
├── tests/
│   ├── conftest.py                 # Shared fixtures and sample data
│   ├── unit/
│   │   ├── test_ownership_resolver.py
│   │   ├── test_keycloak_sync.py
│   │   ├── test_opa_policy_builder.py
│   │   ├── test_configmap_sync.py
│   │   └── test_event_listener.py
│   └── integration/
│       └── test_reconciler.py
├── charts/attribute-bridge/         # Helm chart (recommended for Kubernetes)
├── k8s/                             # Flat Kubernetes manifests (reference / kubectl)
├── Dockerfile
├── docker-compose.yml
├── Makefile
├── pyproject.toml
├── .env.example
└── README.md
```

---

## Environment variables

| Variable | Default | Description |
|---|---|---|
| `DATAHUB_URL` | `http://localhost:8080` | DataHub GMS base URL |
| `DATAHUB_TOKEN` | *(empty)* | DataHub personal access token |
| `DATAHUB_KAFKA_BOOTSTRAP_SERVERS` | `localhost:9092` | Kafka bootstrap servers |
| `DATAHUB_KAFKA_TOPIC` | `MetadataChangeLog_Versioned_v1` | MCL Kafka topic |
| `DATAHUB_KAFKA_CONSUMER_GROUP` | `attribute-bridge` | Kafka consumer group |
| `DATAHUB_EVENT_SOURCE` | `kafka` | `kafka` (aiokafka+JSON), `actions` (embedded [DataHub Actions](https://docs.datahub.com/docs/datahub-actions) via `Pipeline.create(dict)`, install `pip install '.[actions]'`), or `polling` |
| `DATAHUB_SCHEMA_REGISTRY_URL` | *(empty)* | When using `actions`: Schema Registry URL (often DataHub GMS `/schema-registry/api/`). Empty uses DataHub SDK defaults / `KAFKA_SCHEMAREGISTRY_URL` |
| `KEYCLOAK_URL` | `http://localhost:8180` | Keycloak base URL |
| `KEYCLOAK_REALM` | `master` | Keycloak realm |
| `KEYCLOAK_CLIENT_ID` | `attribute-bridge` | Service account client ID |
| `KEYCLOAK_CLIENT_SECRET` | `changeme` | Service account client secret |
| `KEYCLOAK_GROUP_ATTRIBUTE_NAME` | `allowed_access` | Keycloak attribute key managed by this service |
| `KEYCLOAK_GROUP_MATCH_MODE` | `name` | `name` = same group name in DataHub and Keycloak; `mapping` = use `GROUP_NAME_MAPPING` (see below) |
| `K8S_NAMESPACE` | `trino` | Namespace for the OPA ConfigMap |
| `K8S_CONFIGMAP_NAME` | `opa-trino-policy` | ConfigMap name |
| `K8S_CONFIGMAP_KEY` | `policy_data.json` | Key inside the ConfigMap |
| `K8S_IN_CLUSTER` | `false` | `true` = pod service account; `false` = kubeconfig for local dev |
| `RECONCILE_INTERVAL_SECONDS` | `300` | Seconds between full reconciliation runs (only when `RECONCILE_ENABLED=true`) |
| `RECONCILE_ENABLED` | `false` | When `true`, run a background loop on that interval; otherwise use events / polling / manual reconcile only |
| `LOG_LEVEL` | `DEBUG` | Logging level (`INFO` recommended in production) |
| `READINESS_STRICT` | `false` | When `true`, `GET /ready` returns 503 if startup dependency probes failed or required Kafka/actions pipeline did not start (set `true` in Kubernetes) |
| `DRY_RUN` | `false` | Compute state without writing to downstream systems |
| `GROUP_NAME_MAPPING` | `{}` | JSON object mapping **DataHub corp-group short names** → **Keycloak group names**; only used when `KEYCLOAK_GROUP_MATCH_MODE=mapping` (see below) |

### Group name mapping

DataHub identifies groups as corp groups (e.g. URN `urn:li:corpGroup:foogroup` → short name `foogroup`). Keycloak has its own group names. By default the service assumes **the short name is identical** in both systems: it resolves ownership in DataHub using that name and updates the Keycloak group with the **same** name.

When our IdP or naming conventions differ, for example DataHub uses `data-platform-team` but Keycloak uses `dp-team`, we could configure explicit mapping (not ideal but just in case):

1. Set **`KEYCLOAK_GROUP_MATCH_MODE=mapping`**.
2. Set **`GROUP_NAME_MAPPING`** to a JSON object whose keys are **DataHub** group short names and values are **Keycloak** group names.

Example (env-friendly JSON on one line):

```text
GROUP_NAME_MAPPING={"data-platform-team":"dp-team","foogroup":"bi-foogroup"}
```

**OPA / ConfigMap policy:** The generated JSON under `groups` uses **DataHub** group short names as keys (the source of truth), not Keycloak names. Trino/OPA rules should key off the same identifiers our auth layer exposes (e.g. JWT claims). If tokens carry Keycloak group names, align DataHub names with those or extend the policy builder later to emit Keycloak names.

Implementation detail: mapping is handled in `app/services/group_mapper.py` (`DirectGroupNameMapper` vs `ConfigurableGroupNameMapper`).

---

## Local setup

### Prerequisites

- Python 3.12+
- Docker & Docker Compose (for local dependencies)
- A `.env` file (copy from `.env.example`)

### Install

```bash
# Create virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install with dev dependencies
make dev
```

### Start local dependencies

```bash
# Starts Keycloak + Kafka (no DataHub, we'll need our own instance or mocks)
make docker-up
```

### Package the project as a zip

Creates ``dist/attribute-bridge-<version>.zip`` (from ``pyproject.toml``), including app source, Helm chart, ``k8s/``, Dockerfile, and docs. Excludes ``.venv``, caches, ``.git``, ``.env``, and the ``dist/`` output itself.

```bash
make package
```

### Run the service

```bash
# Uses uvicorn with auto-reload
make run
```

The service starts at `http://localhost:8000`. After Uvicorn finishes startup, it logs a short **External connections** block with one line per system, for example `DataHub connection successful — …` or `Keycloak connection failed — ConnectionError: …`. In an interactive terminal (stderr TTY), component names and success/failure states are colorized via **Colorama** (including Windows consoles); plain text is used when stderr is not a TTY (e.g. JSON logs).

Endpoints:

| Endpoint | Method | Description |
|---|---|---|
| `/health` | GET | Liveness probe |
| `/ready` | GET | Readiness probe |
| `/metrics` | GET | Basic operational metrics |
| `/admin/reconcile` | POST | Trigger immediate full reconciliation |
| `/admin/dry-run` | POST | Dry-run reconciliation (no writes) |
| `/docs` | GET | OpenAPI documentation (Swagger UI) |

---

## Testing

```bash
# Optional: include DataHub Actions tests and embedded pipeline code paths
pip install -e ".[dev,actions]"

# Run all tests
make test

# Run with coverage report
make test-cov

# Lint
make lint

# Type-check
make type-check
```

All tests use mocked external clients, no DataHub, Keycloak, or Kubernetes cluster required.

---

## OPA policy format

The generated policy data document follows this schema. Top-level `groups` keys are **DataHub corp-group short names** (same as in metadata), not Keycloak names,see [Group name mapping](#group-name-mapping) if we use `GROUP_NAME_MAPPING` for Keycloak only.

```json
{
  "groups": {
    "foogroup": {
      "allowed_access": [
        "urn:li:dataset:(urn:li:dataPlatform:trino,sales.customers,PROD)",
        "urn:li:dataset:(urn:li:dataPlatform:trino,sales.orders,PROD)"
      ]
    },
    "marketing": {
      "allowed_access": [
        "urn:li:dataset:(urn:li:dataPlatform:trino,marketing.campaigns,PROD)"
      ]
    }
  }
}
```

Groups and URNs are sorted lexicographically for deterministic output. The policy renderer is encapsulated in `OpaPolicyBuilder` and can be swapped for a different OPA data model without changing the rest of the codebase.

---

## Deployment

### Docker

```bash
make docker-build
docker run --env-file .env -p 8000:8000 attribute-bridge:latest
```

### Kubernetes (Helm)

The ready-to-use chart lives in `charts/attribute-bridge/`. See `charts/attribute-bridge/README.md` for options (`values.yaml`, secrets, image overrides).

By default the chart does **not** create the Secret (`secret.create: false`). Create `attribute-bridge-secrets` (or set `secret.name`) with `DATAHUB_TOKEN` and `KEYCLOAK_CLIENT_SECRET` **before** install, or use `secret.create: true` only for bootstrap.

```bash
helm lint ./charts/attribute-bridge
helm template attribute-bridge ./charts/attribute-bridge -n attribute-bridge \
  -f charts/attribute-bridge/ci/default-values.yaml   # adds a throwaway Secret for dry-run
helm install attribute-bridge ./charts/attribute-bridge \
  --namespace attribute-bridge \
  --create-namespace \
  --set image.repository=your-registry/attribute-bridge \
  --set image.tag=0.1.0
```

Override `opa.configMap.namespace` / `opa.configMap.name` if your OPA ConfigMap is not in `trino` / `opa-trino-policy`. Defaults use `LOG_LEVEL=INFO`, `READINESS_STRICT=true`, pinned-style `image.tag`, and a non-root / read-only root filesystem (with `/tmp` emptyDir).

### Kubernetes (flat manifests)

Manifests in `k8s/` match the chart defaults. Apply in order:

```bash
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/serviceaccount.yaml
kubectl apply -f k8s/rbac.yaml
kubectl apply -f k8s/secret.yaml       # edit with real credentials first
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
```

The RBAC role grants the service account permission to read, create, and patch the OPA policy ConfigMap in the target namespace (`trino` in the defaults). The Deployment uses a `Recreate` strategy with a single replica to prevent concurrent writes.

### Test checklist

- Replace secret values with real credentials (use sealed-secrets or external-secrets)
- Set `DATAHUB_EVENT_SOURCE=kafka` and verify Kafka connectivity (with `READINESS_STRICT=true`, a failed Kafka consumer startup marks `/ready` as 503)
- Verify Keycloak service account has group-management permissions
- Keep **one replica** unless you redesign ConfigMap single-writer semantics
- Set appropriate resource limits based on load testing
- Configure monitoring/alerting on the `/metrics` endpoint
- Set `RECONCILE_ENABLED=true` if you want periodic full scans; tune `RECONCILE_INTERVAL_SECONDS` for SLA

---

## How it works

### Event-driven flow

1. **Kafka consumer** reads `MetadataChangeLog` events from the DataHub MCL topic.
2. **Event filter** act only on events where `entityType=dataProduct`, `aspectName=ownership`, and at least one owner is a `corpGroup`.
3. For each affected group, the **Ownership Resolver** calls the DataHub GraphQL API to recompute the full set of datasets accessible through all Data Products the group still owns.
4. **Keycloak Sync** writes the recomputed URN list as the `allowed_access` attribute on the corresponding Keycloak group.
5. **OPA Policy Builder** generates a complete policy JSON from all groups' current state.
6. **ConfigMap Sync** validates the policy and writes it to the Kubernetes ConfigMap.

### Periodic reconciliation

When **`RECONCILE_ENABLED=true`**, a background loop runs every `RECONCILE_INTERVAL_SECONDS` and performs a full scan. With the default **`RECONCILE_ENABLED=false`**, no periodic loop runs; use real-time events, the `polling` event source, or a manual `POST /admin/reconcile` instead.

When enabled, the loop:

1. Lists all Data Products in DataHub.
2. For each, fetches group owners.
3. For each group, resolves all datasets.
4. Syncs everything to Keycloak and the ConfigMap.

This repairs drift from missed events, partial failures, or manual changes.

### Critical business rule

When a group is removed as owner from one Data Product, the service does **not** blindly clear that group's access. It recomputes all dataset URNs the group still owns through all remaining Data Products and syncs that full state downstream.

---

